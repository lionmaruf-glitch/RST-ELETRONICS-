import React, { useState } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  Save,
  RotateCcw,
  Wrench,
  Camera,
  Building2,
  Package,
  Radio,
  Sparkles,
  Users,
  Wallet,
  ShieldCheck,
  Edit3,
  Check,
} from 'lucide-react';
import { SoundEngine, generateEAN13, generateIMEI, generateSerialNo } from '../utils/erpHelpers';

interface AdminMasterEditorProps {
  db: any;
  onSyncDB: (partial: any, logAction?: string, moduleName?: string) => Promise<void>;
  onResetDefaultDB: () => Promise<void>;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
}

type CollectionKey =
  | 'products'
  | 'categories'
  | 'departments'
  | 'companies'
  | 'units'
  | 'telecomOperators'
  | 'utilityOperators'
  | 'subscriptionPlans'
  | 'offers'
  | 'customers'
  | 'branches'
  | 'employees'
  | 'users'
  | 'repairTickets'
  | 'cctvMonitors'
  | 'pendingServices'
  | 'expenses'
  | 'warranties'
  | 'installments'
  | 'targets';

const COLLECTION_META: {
  key: CollectionKey;
  label: string;
  description: string;
  defaultNewItem: () => any;
}[] = [
  {
    key: 'products',
    label: 'Products & IMEI Stock',
    description: 'Edit every product name (EN/BN/AR), barcode, IMEI, serial number, cost, retail/wholesale price, stock, and warranty.',
    defaultNewItem: () => ({
      id: Date.now(),
      nameEn: 'New Flagship Device',
      nameBn: 'নতুন ডিভাইস',
      nameAr: 'جهاز جديد',
      category: 'Mobile',
      brand: 'Apple',
      company: 'Apple Inc.',
      department: 'Electronics',
      unit: 'Pcs',
      model: 'A3000',
      variant: '256GB',
      barcode: generateEAN13(),
      imei: generateIMEI(),
      serialNo: generateSerialNo(),
      cost: 200.0,
      price: 245.0,
      wholesale: 230.0,
      stock: 10,
      lowStockAlert: 3,
      warranty: '1 Year Official Warranty',
      featured: true,
      active: true,
      is_deleted: false,
    }),
  },
  {
    key: 'categories',
    label: 'Categories (EN/BN/AR)',
    description: 'Add, rename, or remove product categories in English, Bengali, and Arabic.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Category',
      nameBn: 'নতুন ক্যাটাগরি',
      nameAr: 'فئة جديدة',
    }),
  },
  {
    key: 'departments',
    label: 'Departments',
    description: 'Manage organizational & inventory departments.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Department',
    }),
  },
  {
    key: 'companies',
    label: 'Suppliers & Brands',
    description: 'Manage manufacturer companies and regional distributors.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Supplier LLC',
    }),
  },
  {
    key: 'units',
    label: 'Measurement Units',
    description: 'Customize stock measurement units (Pcs, Box, Carton, Meter, Set).',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'Pack',
    }),
  },
  {
    key: 'telecomOperators',
    label: 'Oman Telecom Operators',
    description: 'Customize operator names, brand colors, dealer pool balances, commission types (fixed/%), latency, and SLA.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Oman Operator',
      code: 'OPR',
      color: '#059669',
      balance: 100.0,
      commissionType: 'percent',
      commissionValue: 2.5,
      latencyMs: 15,
      reliability: 99.95,
      packetLoss: 0.01,
      status: 'Optimal',
      is_active: true,
    }),
  },
  {
    key: 'utilityOperators',
    label: 'Oman Utility Billers',
    description: 'Configure electricity, water, and fiber bill payment providers and commission percentages.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Utility Biller',
      code: 'UTL',
      color: '#0284c7',
      commissionType: 'percent',
      commissionValue: 1.5,
      is_active: true,
    }),
  },
  {
    key: 'subscriptionPlans',
    label: 'Telecom Plan Comparison Cards',
    description: 'Edit 5G/Fiber subscription plans, monthly fees, GB quotas, local/intl minutes, speeds, and dealer margins.',
    defaultNewItem: () => ({
      id: Date.now(),
      operator: 'Omantel',
      planName: 'New 5G Plan',
      priceOmr: 10.0,
      validityDays: 30,
      dataGb: 40,
      socialDataGb: 15,
      localMinutes: 500,
      intlMinutes: 40,
      dealerMarginPct: 2.5,
      speedMbps: 500,
      badge: 'Featured Plan',
    }),
  },
  {
    key: 'offers',
    label: 'Promotional Offers & Campaigns',
    description: 'Customize storefront and POS promotional offers, discount percentages/OMR, and target VIP segments.',
    defaultNewItem: () => ({
      id: Date.now(),
      titleEn: 'New Seasonal Offer',
      titleBn: 'নতুন বিশেষ অফার',
      titleAr: 'عرض موسمي جديد',
      description: 'Special discount on selected items',
      type: 'percent',
      value: 10,
      category: 'Mobile',
      minPurchase: 50.0,
      targetSegment: 'All',
      active: true,
    }),
  },
  {
    key: 'customers',
    label: 'VIP Customers & Credit Ledger',
    description: 'Edit customer names, phones, emails, branches, VIP tiers, loyalty points, and credit balances.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Customer',
      phone: '+968 9000 0000',
      email: 'customer@omanmail.om',
      address: 'Muscat, Oman',
      branch: 'Mabellah Main Branch',
      totalPurchases: 0,
      segment: 'Regular',
      loyaltyPoints: 0,
      balance: 0,
      is_deleted: false,
    }),
  },
  {
    key: 'branches',
    label: 'Oman Regional Branches',
    description: 'Add or edit branch locations, addresses, hotlines, and branch managers.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Regional Branch',
      address: 'Muscat, Sultanate of Oman',
      phone: '+968 9430 1393',
      manager: 'Branch Manager',
      is_active: true,
    }),
  },
  {
    key: 'employees',
    label: 'Employees & Payroll',
    description: 'Edit staff names, designations, assigned branches, base salaries (OMR), and sales commission rates.',
    defaultNewItem: () => ({
      id: Date.now(),
      name: 'New Staff Member',
      position: 'Sales Executive',
      branch: 'Mabellah Main Branch',
      phone: '+968 9000 0000',
      salary: 320.0,
      commissionPct: 1.0,
      joinDate: new Date().toISOString().slice(0, 10),
      status: 'Active',
    }),
  },
  {
    key: 'users',
    label: 'System Users, Roles & PINs',
    description: 'Full admin control over login usernames, passwords, 4-digit PINs, roles (admin/manager/staff/dealer), and branches.',
    defaultNewItem: () => ({
      id: Date.now(),
      username: `user_${Math.floor(100 + Math.random() * 900)}`,
      password: '123',
      pin: '1111',
      fullname: 'New ERP Operator',
      email: 'operator@rstelectronics.om',
      phone: '+968 9430 1393',
      role: 'staff',
      branch: 'Mabellah Main Branch',
      permissions: ['dashboard', 'pos', 'inventory', 'telecom'],
      is_deleted: false,
    }),
  },
  {
    key: 'repairTickets',
    label: 'Mobile & Device Repair Job Cards',
    description: 'Create and edit mobile/laptop repair tickets, IMEI diagnostics, advance payments, and technician statuses.',
    defaultNewItem: () => ({
      id: Date.now(),
      ticketNumber: `JOB-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: 'Walk-in Repair Client',
      customerPhone: '+968 9000 0000',
      deviceModel: 'iPhone 15 Pro',
      imei: generateIMEI(),
      issueDescription: 'Screen / Battery service',
      status: 'received',
      estimatedCost: 35.0,
      advancePaid: 10.0,
      technician: 'Kamrul Hasan',
      branch: 'Mabellah Main Branch',
    }),
  },
  {
    key: 'cctvMonitors',
    label: 'CCTV Cameras & NVR Channels',
    description: 'Edit showroom and warehouse CCTV security cameras, IP addresses, resolutions, and retention settings.',
    defaultNewItem: () => ({
      id: Date.now(),
      cameraName: 'CAM-05 · New Security Feed',
      branch: 'Mabellah Main Branch',
      ipAddress: '192.168.10.105',
      resolution: '4K UHD · 60fps',
      status: 'Online',
      recordingMode: '24/7 NVR + Cloud',
      retentionDays: 30,
    }),
  },
  {
    key: 'pendingServices',
    label: 'Pending Service Bottlenecks',
    description: 'Track delayed repairs, CCTV field installations, warranty claims, and priority escalations.',
    defaultNewItem: () => ({
      id: Date.now(),
      serviceType: 'mobile_repair',
      referenceCode: `REF-${Math.floor(100 + Math.random() * 900)}`,
      customerName: 'Client Name',
      customerPhone: '+968 9000 0000',
      deviceOrSite: 'Device or Site',
      daysPending: 1,
      reasonCategory: 'Parts in transit',
      priority: 'normal',
      status: 'pending',
    }),
  },
  {
    key: 'expenses',
    label: 'Showroom Expenses & Petty Cash',
    description: 'Edit or log shop rent, electricity, fiber bills, and daily operational expenses.',
    defaultNewItem: () => ({
      id: Date.now(),
      date: new Date().toISOString().slice(0, 10),
      category: 'Operational Expense',
      description: 'Showroom supply expense',
      amount: 15.0,
      paymentMethod: 'Cash',
      branch: 'Mabellah Main Branch',
    }),
  },
  {
    key: 'warranties',
    label: 'IMEI Warranty Certificates',
    description: 'Manage active customer warranty certificates, start/expiry dates, and claim statuses.',
    defaultNewItem: () => ({
      id: Date.now(),
      invoiceNo: 'RST-00001',
      customer: 'Customer Name',
      product: 'Device Name',
      imei: generateIMEI(),
      startDate: new Date().toISOString().slice(0, 10),
      expiryDate: '2027-10-10',
      status: 'Active',
    }),
  },
  {
    key: 'installments',
    label: 'Customer Installment Plans (EMI)',
    description: 'Edit monthly installment plans, down payments, remaining balances, and due dates.',
    defaultNewItem: () => ({
      id: Date.now(),
      customer: 'Customer Name',
      product: 'Device Name',
      total: 300.0,
      downPayment: 100.0,
      monthlyInstallment: 50.0,
      remainingBalance: 200.0,
      nextDueDate: '2026-11-01',
      status: 'Active',
    }),
  },
  {
    key: 'targets',
    label: 'Branch Sales Targets',
    description: 'Configure monthly sales targets and achieved revenue per Oman branch.',
    defaultNewItem: () => ({
      id: Date.now(),
      branch: 'Mabellah Main Branch',
      period: 'October 2026',
      targetOmr: 10000.0,
      achievedOmr: 5000.0,
    }),
  },
];

export const AdminMasterEditor: React.FC<AdminMasterEditorProps> = ({
  db,
  onSyncDB,
  onResetDefaultDB,
  showToast,
}) => {
  const [selectedKey, setSelectedKey] = useState<CollectionKey>('products');
  const [filterText, setFilterText] = useState<string>('');

  const activeMeta = COLLECTION_META.find((m) => m.key === selectedKey) || COLLECTION_META[0];
  const records: any[] = db[selectedKey] || [];

  const handleFieldChange = async (recordId: any, field: string, rawValue: any, originalType: string) => {
    let parsedValue: any = rawValue;
    if (originalType === 'number') {
      parsedValue = rawValue === '' ? 0 : Number(rawValue);
    } else if (originalType === 'boolean') {
      parsedValue = Boolean(rawValue);
    }

    const updatedList = records.map((item) =>
      item.id === recordId ? { ...item, [field]: parsedValue } : item
    );
    await onSyncDB({ [selectedKey]: updatedList });
  };

  const handleAddRecord = async () => {
    SoundEngine.success();
    const newRec = activeMeta.defaultNewItem();
    const updatedList = [newRec, ...records];
    await onSyncDB(
      { [selectedKey]: updatedList },
      `Admin added new record in ${activeMeta.label}`,
      'MasterEditor'
    );
    showToast(`Added new item to ${activeMeta.label}`, 'success');
  };

  const handleDeleteRecord = async (recordId: any) => {
    SoundEngine.click();
    const updatedList = records.filter((item) => item.id !== recordId);
    await onSyncDB(
      { [selectedKey]: updatedList },
      `Admin deleted record #${recordId} from ${activeMeta.label}`,
      'MasterEditor'
    );
    showToast(`Removed record from ${activeMeta.label}`, 'info');
  };

  // Determine columns dynamically from the first item or default template
  const sampleItem = records[0] || activeMeta.defaultNewItem();
  const editableFields = Object.keys(sampleItem).filter(
    (k) => k !== 'id' && k !== 'items' && k !== 'permissions'
  );

  const filteredRecords = records.filter((r) => {
    if (!filterText.trim()) return true;
    return JSON.stringify(r).toLowerCase().includes(filterText.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-700 text-xs font-bold uppercase tracking-wider">
            <Sliders className="h-4 w-4" />
            <span>Universal Admin Master Control Studio</span>
          </div>
          <h1 className="text-xl font-bold text-slate-950 mt-1">
            100% Admin-Editable System Tables, Options, Dropdowns & Configurations
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Every collection, category, operator margin, branch, user role, repair job, CCTV channel, and pricing parameter is live-editable below and syncs immediately to the cloud database.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={handleAddRecord}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Add New Row to {activeMeta.label}</span>
          </button>
          <button
            onClick={onResetDefaultDB}
            className="inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Factory Reset Demo DB</span>
          </button>
        </div>
      </div>

      {/* Collection Selector Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2">
        {COLLECTION_META.map((meta) => {
          const count = (db[meta.key] || []).length;
          const isSelected = selectedKey === meta.key;
          return (
            <button
              key={meta.key}
              onClick={() => {
                SoundEngine.click();
                setSelectedKey(meta.key);
                setFilterText('');
              }}
              className={`rounded-lg border px-3 py-2.5 text-left transition-all ${
                isSelected
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="truncate">{meta.label}</span>
                <span
                  className={`ml-1.5 font-mono text-[11px] ${
                    isSelected ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                >
                  {count}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Table Live Spreadsheet Editor */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Editing: {activeMeta.label} ({filteredRecords.length} rows)
            </h2>
            <p className="text-xs text-slate-500">{activeMeta.description}</p>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder={`Search inside ${activeMeta.label}...`}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs w-64 focus:border-emerald-600 focus:outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-[540px]">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-100 text-slate-700 border-b border-slate-200 z-10">
              <tr>
                <th className="py-2.5 px-2.5 font-mono text-[11px]">ID</th>
                {editableFields.map((field) => (
                  <th key={field} className="py-2.5 px-2.5 font-semibold capitalize whitespace-nowrap">
                    {field.replace(/([A-Z])/g, ' $1')}
                  </th>
                ))}
                <th className="py-2.5 px-2.5 text-right">Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRecords.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/80">
                  <td className="py-2 px-2.5 font-mono text-[11px] text-slate-400">
                    {String(row.id).slice(-5)}
                  </td>
                  {editableFields.map((field) => {
                    const val = row[field];
                    const valType = typeof sampleItem[field];

                    if (valType === 'boolean') {
                      return (
                        <td key={field} className="py-2 px-2.5">
                          <input
                            type="checkbox"
                            checked={Boolean(val)}
                            onChange={(e) =>
                              handleFieldChange(row.id, field, e.target.checked, 'boolean')
                            }
                            className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                          />
                        </td>
                      );
                    }

                    if (field === 'color') {
                      return (
                        <td key={field} className="py-2 px-2.5">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="color"
                              value={val || '#059669'}
                              onChange={(e) =>
                                handleFieldChange(row.id, field, e.target.value, 'string')
                              }
                              className="h-6 w-8 rounded border border-slate-300 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={val || ''}
                              onChange={(e) =>
                                handleFieldChange(row.id, field, e.target.value, 'string')
                              }
                              className="w-20 rounded border border-slate-200 px-1.5 py-1 font-mono text-[11px]"
                            />
                          </div>
                        </td>
                      );
                    }

                    return (
                      <td key={field} className="py-1.5 px-2">
                        <input
                          type={valType === 'number' ? 'number' : 'text'}
                          step={valType === 'number' ? 'any' : undefined}
                          value={val ?? ''}
                          onChange={(e) =>
                            handleFieldChange(row.id, field, e.target.value, valType)
                          }
                          className={`min-w-[110px] w-full rounded border border-slate-200 bg-white px-2 py-1 text-xs focus:border-emerald-600 focus:outline-none ${
                            valType === 'number' ? 'font-mono text-right tabular-nums' : ''
                          }`}
                        />
                      </td>
                    );
                  })}
                  <td className="py-2 px-2.5 text-right">
                    <button
                      type="button"
                      onClick={() => handleDeleteRecord(row.id)}
                      className="rounded p-1 text-rose-600 hover:bg-rose-50"
                      title="Delete row"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
