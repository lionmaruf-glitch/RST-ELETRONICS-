import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Zap,
  ShieldCheck,
  Truck,
  PhoneCall,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  SlidersHorizontal,
  ArrowUpDown,
  Smartphone,
  Tv,
  Laptop,
  Headphones,
  Watch,
  Cpu,
} from 'lucide-react';
import { SoundEngine, printTaxInvoice } from '../utils/erpHelpers';

interface StorefrontViewProps {
  db: any;
  lang: 'en' | 'bn' | 'ar';
  t: (key: string, fallback?: string) => string;
  onSyncDB: (partial: any, logAction?: string, moduleName?: string) => Promise<void>;
  onNotify: (title: string, body: string, type?: string) => Promise<void>;
  onSwitchToErp: () => void;
}

export const StorefrontView: React.FC<StorefrontViewProps> = ({
  db,
  lang,
  t,
  onSyncDB,
  onNotify,
  onSwitchToErp,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [cart, setCart] = useState<any[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'catalog' | 'telecom' | 'compare'>('catalog');
  const [rechargeOperatorId, setRechargeOperatorId] = useState<number>(1);
  const [rechargePhone, setRechargePhone] = useState<string>('+968 ');
  const [rechargeAmount, setRechargeAmount] = useState<string>('5.000');

  const config = db.themeConfig || {};
  const decimals = config.decimalPlaces ?? 3;
  const fmt = (n: any) => Number(n || 0).toFixed(decimals);

  const getProductName = (p: any) => {
    if (lang === 'bn' && p.nameBn) return p.nameBn;
    if (lang === 'ar' && p.nameAr) return p.nameAr;
    return p.nameEn || p.name;
  };

  const getCategoryLabel = (c: any) => {
    if (lang === 'bn' && c.nameBn) return c.nameBn;
    if (lang === 'ar' && c.nameAr) return c.nameAr;
    return c.name;
  };

  const filteredProducts = (db.products || []).filter((p: any) => {
    if (p.is_deleted || !p.active) return false;
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      (p.nameEn || '').toLowerCase().includes(q) ||
      (p.nameBn || '').toLowerCase().includes(q) ||
      (p.nameAr || '').toLowerCase().includes(q) ||
      (p.brand || '').toLowerCase().includes(q) ||
      (p.barcode || '').includes(q) ||
      (p.imei || '').includes(q);
    return matchesCat && matchesSearch;
  });

  const addToCart = (product: any) => {
    SoundEngine.beep();
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) return prev;
        return prev.map((item) =>
          item.id === product.id ? { ...item, qty: item.qty + 1 } : item
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          name: getProductName(product),
          price: product.price,
          cost: product.cost,
          barcode: product.barcode,
          imei: product.imei,
          qty: 1,
        },
      ];
    });
  };

  const updateCartQty = (id: number, delta: number) => {
    SoundEngine.click();
    setCart((prev) =>
      prev
        .map((item) => (item.id === id ? { ...item, qty: item.qty + delta } : item))
        .filter((item) => item.qty > 0)
    );
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const cartVat = cartSubtotal * ((config.vatRate ?? 5) / 100);
  const cartGrandTotal = cartSubtotal + cartVat;

  const handleStoreCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cart.length) return;
    const nextInvId = (db.invoices?.length || 0) + 1;
    const invNo = `WEB-${String(nextInvId).padStart(5, '0')}`;
    const profit = cart.reduce((s, i) => s + (i.price - i.cost) * i.qty, 0);

    const newInvoice = {
      id: Date.now(),
      invoice_no: invNo,
      date: new Date().toISOString(),
      customer: customerName.trim() || 'Online Store Customer',
      phone: customerPhone.trim() || '',
      branch: 'Online Storefront (Oman)',
      items: cart,
      subtotal: cartSubtotal,
      discount: 0,
      vat: cartVat,
      grand_total: cartGrandTotal,
      payment: 'Online Card / Wallet',
      profit,
      status: 'Paid',
      operator: 'storefront',
      is_deleted: false,
    };

    const updatedProducts = (db.products || []).map((p: any) => {
      const cItem = cart.find((c) => c.id === p.id);
      if (cItem) {
        return { ...p, stock: Math.max(0, p.stock - cItem.qty) };
      }
      return p;
    });

    await onSyncDB(
      {
        invoices: [newInvoice, ...(db.invoices || [])],
        products: updatedProducts,
      },
      `Online Store Order ${invNo} (${fmt(cartGrandTotal)} ${config.currency})`,
      'Storefront'
    );

    await onNotify(
      `New Storefront Order ${invNo}`,
      `Customer ${newInvoice.customer} placed order ${invNo} for ${fmt(cartGrandTotal)} ${config.currency}.`,
      'sale'
    );

    SoundEngine.success();
    printTaxInvoice(newInvoice, config, 'a4');
    setCart([]);
    setIsCartOpen(false);
    setCustomerName('');
    setCustomerPhone('');
  };

  const handleInstantRecharge = async (e: React.FormEvent) => {
    e.preventDefault();
    const op = (db.telecomOperators || []).find((o: any) => o.id === Number(rechargeOperatorId));
    const amt = parseFloat(rechargeAmount);
    if (!op || isNaN(amt) || amt <= 0) return;

    const profit =
      op.commissionType === 'fixed'
        ? Number(op.commissionValue)
        : (amt * Number(op.commissionValue)) / 100;

    const newTx = {
      id: Date.now(),
      txNo: `TOP-${Math.floor(1000 + Math.random() * 9000)}`,
      operatorId: op.id,
      operatorName: op.name,
      phone: rechargePhone,
      amount: amt,
      profit,
      previousBalance: op.balance,
      newBalance: Math.max(0, op.balance - amt),
      date: new Date().toISOString(),
      dealer: 'online_self_service',
      branch: 'Online Portal',
    };

    const updatedOps = (db.telecomOperators || []).map((o: any) =>
      o.id === op.id ? { ...o, balance: Math.max(0, o.balance - amt) } : o
    );

    await onSyncDB(
      {
        telecomOperators: updatedOps,
        telecomTransactions: [newTx, ...(db.telecomTransactions || [])],
      },
      `Online Recharge ${op.name} (${fmt(amt)} OMR)`,
      'Telecom'
    );

    SoundEngine.success();
    await onNotify(
      `Telecom Recharge ${newTx.txNo}`,
      `${op.name} recharge of ${fmt(amt)} OMR for ${rechargePhone}.`,
      'telecom'
    );
  };

  const getCategoryIcon = (catName: string) => {
    switch (catName) {
      case 'Mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'TV':
        return <Tv className="h-4 w-4" />;
      case 'Laptop':
        return <Laptop className="h-4 w-4" />;
      case 'Audio':
        return <Headphones className="h-4 w-4" />;
      case 'Watch':
        return <Watch className="h-4 w-4" />;
      default:
        return <Cpu className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Hero Banner */}
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-6 py-10 lg:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-semibold tracking-wider text-emerald-700 uppercase">
                {config.legalName} · CR {config.crNo} · Sultanate of Oman
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 text-balance">
                {lang === 'bn'
                  ? 'ওমানের বিশ্বস্ত ইলেকট্রনিক্স, মোবাইল ও টেলিকম সুপারস্টোর'
                  : lang === 'ar'
                  ? 'المتجر الأول للإلكترونيات والهواتف الذكية وخدمات الاتصالات في سلطنة عُمان'
                  : 'Authorized Electronics, Flagship 5G Devices & Oman Telecom Hub'}
              </h1>
              <p className="text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
                {lang === 'bn'
                  ? 'অফিসিয়াল ওয়ারেন্টি সহ আইফোন, স্যামসাং, ল্যাপটপ, ৪কে টিভি এবং ওমানটেল, উরিদু, ভোডাফোন ও আওয়াসর ফাইবার রিচার্জ এখন এক ছাদের নিচে।'
                  : lang === 'ar'
                  ? 'تسوق أحدث أجهزة آيفون وسامسونج واللابتوبات مع ضمان رسمي، بالإضافة إلى شحن فوري لجميع شبكات الاتصالات في عُمان.'
                  : 'Shop IMEI-verified smartphones, laptops, and smart appliances with official GCC warranty, plus instant Omantel, Ooredoo, Vodafone, and Awasr bill & top-up services.'}
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => setActiveTab('catalog')}
                  className={`px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'catalog'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'bn' ? 'প্রোডাক্ট ক্যাটালগ' : lang === 'ar' ? 'كتالوج المنتجات' : 'Browse Electronics'}
                </button>
                <button
                  onClick={() => setActiveTab('telecom')}
                  className={`px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'telecom'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'bn' ? 'ওমান টেলিকম ও বিল পে' : lang === 'ar' ? 'شحن الاتصالات والفواتير' : 'Oman Telecom & Utility Top-Up'}
                </button>
                <button
                  onClick={() => setActiveTab('compare')}
                  className={`px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    activeTab === 'compare'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'bn' ? 'অফার ও প্ল্যান তুলনা' : lang === 'ar' ? 'مقارنة باقات الاتصالات' : 'Compare Subscription Plans'}
                </button>
              </div>
            </div>

            {/* Active Promotional Offer Spotlight */}
            <div className="lg:col-span-5">
              <div className="rounded-xl border border-slate-200 bg-slate-900 p-6 text-white space-y-4">
                <div className="flex items-center justify-between text-xs text-amber-400 font-medium">
                  <span>SPECIAL REGIONAL OFFER · MUSCAT & SEEB</span>
                  <span className="font-mono">VAT 5% INCLUSIVE</span>
                </div>
                {(db.offers || []).slice(0, 2).map((offer: any) => (
                  <div
                    key={offer.id}
                    className="rounded-lg border border-slate-800 bg-slate-800/70 p-4 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-white">
                        {lang === 'bn'
                          ? offer.titleBn || offer.titleEn
                          : lang === 'ar'
                          ? offer.titleAr || offer.titleEn
                          : offer.titleEn}
                      </h3>
                      <span className="text-xs font-mono font-bold text-emerald-400">
                        {offer.type === 'percent' ? `${offer.value}% OFF` : `-${fmt(offer.value)} OMR`}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">{offer.description}</p>
                    <div className="text-[11px] text-slate-400">
                      Segment: {offer.targetSegment} · Min Spend: {fmt(offer.minPurchase)} {config.currency}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Trust & Service Bar */}
          <div className="mt-8 pt-6 border-t border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-slate-600">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>100% Official GCC & Apple/Samsung IMEI Warranty</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Truck className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>Same-Day Express Delivery in Muscat, Mabellah & Seeb</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Zap className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>Instant Omantel, Ooredoo, Vodafone & Awasr Top-Up</span>
            </div>
            <div className="flex items-center gap-2.5">
              <PhoneCall className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>24/7 Support: {config.phone} · Mabellah Road 6</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Storefront Content */}
      <div className="mx-auto max-w-7xl px-6 py-8">
        {activeTab === 'catalog' && (
          <div className="space-y-6">
            {/* Search, Category Filter & Cart Trigger */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                <button
                  onClick={() => setSelectedCategory('All')}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    selectedCategory === 'All'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  All Categories ({db.products?.filter((p: any) => !p.is_deleted).length || 0})
                </button>
                {(db.categories || []).map((cat: any) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      selectedCategory === cat.name
                        ? 'bg-slate-900 text-white'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {getCategoryIcon(cat.name)}
                    <span>{getCategoryLabel(cat)}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="relative flex-1 sm:w-72">
                  <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search model, brand, barcode, IMEI..."
                    className="w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3.5 py-2 text-xs focus:border-emerald-600 focus:outline-none"
                  />
                </div>
                <button
                  onClick={() => setIsCartOpen(true)}
                  className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
                >
                  <ShoppingBag className="h-4 w-4" />
                  <span>Cart ({cart.reduce((s, i) => s + i.qty, 0)})</span>
                  <span className="font-mono">· {fmt(cartGrandTotal)} {config.currency}</span>
                </button>
              </div>
            </div>

            {/* Product Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {filteredProducts.map((product: any) => (
                <div
                  key={product.id}
                  className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between hover:border-slate-300 transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                      <span>{product.brand} · {product.category}</span>
                      <span className="font-mono text-[11px]">Stock: {product.stock}</span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-1">
                      {getProductName(product)}
                    </h3>
                    <p className="text-xs text-slate-500 mb-3">
                      {product.variant || product.model} · {product.warranty || 'Official Warranty'}
                    </p>
                    <div className="text-[11px] font-mono text-slate-500 space-y-0.5 mb-4 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <div>Barcode: {product.barcode}</div>
                      {product.imei && <div>IMEI: {product.imei}</div>}
                      {product.serialNo && <div>S/N: {product.serialNo}</div>}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs text-slate-400">Retail Price</div>
                      <div className="text-lg font-bold font-mono text-slate-950 tabular-nums">
                        {fmt(product.price)} <span className="text-xs font-normal">{config.currency}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => addToCart(product)}
                      disabled={product.stock <= 0}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-600 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      Add to Order
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'telecom' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-5">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Oman Telecom Instant Recharge & Fiber Top-Up
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Real-time API gateway for Omantel, Ooredoo, Vodafone, FRiENDi, Renna, and Awasr Fiber.
                </p>
              </div>
              <form onSubmit={handleInstantRecharge} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-2">
                    Select Oman Operator
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {(db.telecomOperators || []).map((op: any) => (
                      <button
                        type="button"
                        key={op.id}
                        onClick={() => setRechargeOperatorId(op.id)}
                        className={`p-3 rounded-lg border text-left transition-all ${
                          rechargeOperatorId === op.id
                            ? 'border-emerald-600 bg-emerald-50/60 ring-1 ring-emerald-600'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className="px-2 py-0.5 rounded text-[10px] font-bold text-white"
                            style={{ backgroundColor: op.color }}
                          >
                            {op.code}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">{op.latencyMs}ms</span>
                        </div>
                        <div className="text-xs font-semibold text-slate-900 mt-2 truncate">
                          {op.name}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Oman Mobile / Account Number
                    </label>
                    <input
                      type="text"
                      value={rechargePhone}
                      onChange={(e) => setRechargePhone(e.target.value)}
                      required
                      className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Recharge Amount ({config.currency})
                    </label>
                    <input
                      type="number"
                      step="0.001"
                      value={rechargeAmount}
                      onChange={(e) => setRechargeAmount(e.target.value)}
                      required
                      className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full rounded-lg bg-emerald-600 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors"
                >
                  Process Instant Recharge ({rechargeAmount} {config.currency})
                </button>
              </form>
            </div>

            <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                Live Oman Operator Network Reliability & Latency
              </h3>
              <p className="text-xs text-slate-500">
                Real-time gateway telemetry across Sultanate of Oman regional switches.
              </p>
              <div className="space-y-3">
                {(db.telecomOperators || []).map((op: any) => (
                  <div
                    key={op.id}
                    className="flex items-center justify-between rounded-lg border border-slate-200 p-3"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-900">{op.name}</div>
                      <div className="text-[11px] text-slate-500">
                        Uptime: {op.reliability}% · Packet Loss: {op.packetLoss}%
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="text-xs font-bold text-emerald-700">{op.latencyMs} ms</div>
                      <div className="text-[11px] text-slate-500">{op.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'compare' && (
          <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Oman Telecom Subscription & Offer Card Comparison Engine
              </h2>
              <p className="text-xs text-slate-500">
                Compare 5G data allowances, international minutes, fiber speeds, and dealer profit margins side-by-side.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase">
                    <th className="py-3 px-4">Operator & Plan</th>
                    <th className="py-3 px-4 text-right">Monthly Price</th>
                    <th className="py-3 px-4 text-right">5G / Fiber Data</th>
                    <th className="py-3 px-4 text-right">Local / Intl Mins</th>
                    <th className="py-3 px-4 text-right">Max Speed</th>
                    <th className="py-3 px-4 text-right">Validity</th>
                    <th className="py-3 px-4">Category Highlight</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {(db.subscriptionPlans || []).map((plan: any) => (
                    <tr key={plan.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {plan.operator} — {plan.planName}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                        {fmt(plan.priceOmr)} {config.currency}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {plan.dataGb >= 9000 ? 'Unlimited Fiber' : `${plan.dataGb} GB + ${plan.socialDataGb} GB`}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {plan.localMinutes}m / {plan.intlMinutes}m
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {plan.speedMbps} Mbps
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {plan.validityDays} Days
                      </td>
                      <td className="py-3 px-4 text-slate-600">{plan.badge}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Slide-over Checkout Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white h-full flex flex-col justify-between p-6 shadow-2xl overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <h3 className="text-base font-bold text-slate-900">
                  Shopping Cart & Tax Invoice Checkout
                </h3>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-900"
                >
                  Close ✕
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500">
                  Your cart is currently empty. Add electronics from the catalog.
                </div>
              ) : (
                <div className="space-y-3">
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between rounded-lg border border-slate-200 p-3 text-xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{item.name}</div>
                        <div className="font-mono text-slate-500">
                          {fmt(item.price)} {config.currency} × {item.qty}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => updateCartQty(item.id, -1)}
                          className="p-1 rounded border border-slate-200 hover:bg-slate-100"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="font-mono px-2 font-bold">{item.qty}</span>
                        <button
                          onClick={() => updateCartQty(item.id, 1)}
                          className="p-1 rounded border border-slate-200 hover:bg-slate-100"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <form onSubmit={handleStoreCheckout} className="space-y-3 border-t border-slate-200 pt-4">
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Full Customer Name *"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="Oman Phone (+968 9xxx xxxx) *"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                />
                <div className="space-y-1 text-xs pt-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Subtotal:</span>
                    <span className="font-mono">{fmt(cartSubtotal)} {config.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">VAT ({config.vatRate}%):</span>
                    <span className="font-mono">{fmt(cartVat)} {config.currency}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-slate-950 pt-1 border-t border-slate-200">
                    <span>Grand Total:</span>
                    <span className="font-mono text-emerald-700">{fmt(cartGrandTotal)} {config.currency}</span>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full rounded-lg bg-emerald-600 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors"
                >
                  Complete Order & Print A4 Invoice
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
