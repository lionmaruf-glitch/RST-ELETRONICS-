import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import JsBarcode from 'jsbarcode';
import { Camera, X, Check, RefreshCw, Barcode } from 'lucide-react';
import { SoundEngine } from '../utils/erpHelpers';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (code: string) => void;
  title?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
  title = 'Scan Barcode / IMEI / Serial Number',
}) => {
  const [status, setStatus] = useState<string>('Initializing camera...');
  const [manualCode, setManualCode] = useState<string>('');
  const scannerRef = useRef<Html5Qrcode | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    let mounted = true;
    const startCamera = async () => {
      try {
        setStatus('Starting camera feed...');
        const scanner = new Html5Qrcode('erp-qr-reader');
        scannerRef.current = scanner;
        await scanner.start(
          { facingMode: 'environment' },
          { fps: 10, qrbox: { width: 250, height: 180 } },
          (decodedText) => {
            if (!mounted) return;
            SoundEngine.beep();
            setStatus(`Scanned: ${decodedText}`);
            onScanSuccess(decodedText);
            onClose();
          },
          () => {}
        );
        if (mounted) {
          setStatus('Camera active — align Barcode, QR, or IMEI label inside frame.');
        }
      } catch (err: any) {
        if (mounted) {
          setStatus('Camera unavailable or permission denied. Use hardware USB scanner or enter code below.');
        }
      }
    };

    const timer = setTimeout(startCamera, 250);

    return () => {
      mounted = false;
      clearTimeout(timer);
      if (scannerRef.current) {
        scannerRef.current
          .stop()
          .then(() => scannerRef.current?.clear())
          .catch(() => {});
        scannerRef.current = null;
      }
    };
  }, [isOpen, onClose, onScanSuccess]);

  if (!isOpen) return null;

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    SoundEngine.beep();
    onScanSuccess(manualCode.trim());
    setManualCode('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-900 px-5 py-4 text-white">
          <div className="flex items-center gap-2.5">
            <Camera className="h-5 w-5 text-emerald-400" />
            <h3 className="text-base font-semibold">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div
            id="erp-qr-reader"
            className="w-full min-h-[240px] rounded-lg bg-slate-900 overflow-hidden flex items-center justify-center text-slate-400 text-xs"
          />

          <div className="rounded-lg bg-slate-100 px-3.5 py-2.5 text-xs text-slate-700 font-medium">
            {status}
          </div>

          <form onSubmit={handleManualSubmit} className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Hardware Scanner Input / Manual Barcode, IMEI, or Serial No:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Scan or type 8901234567890 / 356789123456789..."
                autoFocus
                className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono focus:border-emerald-600 focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
              >
                <Check className="h-4 w-4" />
                Apply Code
              </button>
            </div>
          </form>

          <div className="pt-2 border-t border-slate-200">
            <div className="text-xs text-slate-500 mb-2">Quick Demo Scan Triggers:</div>
            <div className="flex flex-wrap gap-1.5">
              {[
                { label: 'iPhone 15 Pro (8901234567890)', code: '8901234567890' },
                { label: 'Galaxy S24 Ultra (8901234567891)', code: '8901234567891' },
                { label: 'Sony XM5 (8901234567892)', code: '8901234567892' },
                { label: 'IMEI: 356789123456789', code: '356789123456789' },
              ].map((demo) => (
                <button
                  key={demo.code}
                  type="button"
                  onClick={() => {
                    SoundEngine.beep();
                    onScanSuccess(demo.code);
                    onClose();
                  }}
                  className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-mono text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                >
                  {demo.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface BarcodeSvgProps {
  value: string;
  format?: string;
  height?: number;
}

export const BarcodePreview: React.FC<BarcodeSvgProps> = ({
  value,
  format = 'CODE128',
  height = 64,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (svgRef.current && value) {
      try {
        JsBarcode(svgRef.current, value, {
          format,
          width: 1.8,
          height,
          displayValue: true,
          fontSize: 13,
          margin: 6,
        });
      } catch {
        // Fallback if invalid EAN13 checksum
        try {
          JsBarcode(svgRef.current, value, {
            format: 'CODE128',
            width: 1.8,
            height,
            displayValue: true,
            fontSize: 13,
            margin: 6,
          });
        } catch {}
      }
    }
  }, [value, format, height]);

  if (!value) return null;

  return (
    <div className="inline-flex flex-col items-center justify-center rounded-lg border border-slate-200 bg-white p-3">
      <svg ref={svgRef} className="max-w-full" />
    </div>
  );
};
