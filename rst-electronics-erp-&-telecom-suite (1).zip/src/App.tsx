import React, { useEffect, useState, useCallback } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Radio,
  Sparkles,
  Crown,
  Users,
  FileSpreadsheet,
  ShieldAlert,
  Palette,
  Store,
  ScanBarcode,
  Pin,
  PinOff,
  LogOut,
  Plus,
  Trash2,
  Printer,
  Download,
  RefreshCw,
  Mail,
  Activity,
  Check,
  AlertTriangle,
  Search,
  Send,
  Volume2,
  VolumeX,
  Building2,
  ArrowRightLeft,
  Wrench,
  Sliders,
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  sendGmailNotification,
  fetchRecentGmailMessages,
} from './services/googleWorkspace';
import {
  SoundEngine,
  generateEAN13,
  generateIMEI,
  generateSerialNo,
  printTaxInvoice,
  exportToExcelCSV,
} from './utils/erpHelpers';
import { BarcodeScannerModal, BarcodePreview } from './components/BarcodeTools';
import { StorefrontView } from './components/StorefrontView';
import { GeminiCopilot } from './components/GeminiCopilot';
import { AdminMasterEditor } from './components/AdminMasterEditor';

type LanguageCode = 'en' | 'bn' | 'ar';

export default function App() {
  const [db, setDb] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [lang, setLang] = useState<LanguageCode>(
    (localStorage.getItem('rst_erp_lang') as LanguageCode) || 'en'
  );
  const [viewMode, setViewMode] = useState<'erp' | 'storefront'>('erp');
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Login Form State
  const [loginUser, setLoginUser] = useState<string>('admin');
  const [loginPass, setLoginPass] = useState<string>('123');
  const [loginError, setLoginError] = useState<string>('');

  // Google Workspace Gmail State
  const [googleUser, setGoogleUser] = useState<FirebaseUser | null>(null);
  const [gmailToken, setGmailToken] = useState<string | null>(null);
  const [gmailInbox, setGmailInbox] = useState<any[]>([]);
  const [emailConfirmModal, setEmailConfirmModal] = useState<{
    isOpen: boolean;
    to: string;
    subject: string;
    htmlBody: string;
  }>({ isOpen: false, to: '', subject: '', htmlBody: '' });
  const [sendingEmail, setSendingEmail] = useState<boolean>(false);

  // Barcode Scanner State
  const [scannerModal, setScannerModal] = useState<{
    isOpen: boolean;
    target: 'pos' | 'inventory' | 'imei_lookup';
  }>({ isOpen: false, target: 'pos' });
  const [scannedLookupCode, setScannedLookupCode] = useState<string>('');

  // Gemini Executive Summary State
  const [aiSummary, setAiSummary] = useState<string>('');
  const [loadingAiSummary, setLoadingAiSummary] = useState<boolean>(false);

  // POS State
  const [posCart, setPosCart] = useState<any[]>([]);
  const [posSearch, setPosSearch] = useState<string>('');
  const [posCustomerId, setPosCustomerId] = useState<number>(1);
  const [posDiscount, setPosDiscount] = useState<string>('0.000');
  const [posPayMode, setPosPayMode] = useState<string>('Cash');
  const [posCashReceived, setPosCashReceived] = useState<string>('');
  const [posHeldOrders, setPosHeldOrders] = useState<any[]>([]);

  // Inventory New Item State
  const [invTab, setInvTab] = useState<'list' | 'add' | 'barcode' | 'transfer'>('list');
  const [newItem, setNewItem] = useState({
    nameEn: '',
    nameBn: '',
    nameAr: '',
    category: 'Mobile',
    brand: 'Apple',
    company: 'Apple Inc.',
    department: 'Electronics',
    unit: 'Pcs',
    model: '',
    variant: '',
    barcode: generateEAN13(),
    imei: generateIMEI(),
    serialNo: generateSerialNo(),
    cost: '100.000',
    price: '125.000',
    wholesale: '115.000',
    stock: '10',
    warranty: '1 Year Official Warranty',
    hasImei: true,
    boxPack: true,
    featured: true,
  });
  const [customBarcodeValue, setCustomBarcodeValue] = useState<string>('8901234567890');
  const [newCategoryName, setNewCategoryName] = useState<string>('');
  const [newCategoryBn, setNewCategoryBn] = useState<string>('');
  const [newCategoryAr, setNewCategoryAr] = useState<string>('');

  // Telecom & Utility State
  const [selectedTelecomOpId, setSelectedTelecomOpId] = useState<number>(1);
  const [telecomPhone, setTelecomPhone] = useState<string>('+968 9430 1393');
  const [telecomAmount, setTelecomAmount] = useState<string>('5.000');
  const [latencySimulating, setLatencySimulating] = useState<boolean>(false);

  // Reports Date Filter State
  const [reportFromDate, setReportFromDate] = useState<string>(
    new Date(Date.now() - 86400000 * 30).toISOString().slice(0, 10)
  );
  const [reportToDate, setReportToDate] = useState<string>(
    new Date().toISOString().slice(0, 10)
  );

  // Toast Notification Banner
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = useCallback((text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.text === text ? null : prev));
    }, 3500);
  }, []);

  // Fetch initial Cloud DB and subscribe to SSE stream
  const fetchCloudState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      const data = await res.json();
      setDb(data);
      if (data?.themeConfig?.soundEnabled !== undefined) {
        SoundEngine.enabled = Boolean(data.themeConfig.soundEnabled);
      }
      if (!currentUser && data?.users?.length) {
        setCurrentUser(data.users[0]);
      }
    } catch (err) {
      console.error('Failed to load cloud state:', err);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchCloudState();
    const evtSource = new EventSource('/api/stream');
    evtSource.onmessage = () => {
      fetchCloudState();
    };
    return () => evtSource.close();
  }, [fetchCloudState]);

  // Initialize Google Workspace Auth listener
  useEffect(() => {
    const unsub = initAuth(
      (u, token) => {
        setGoogleUser(u);
        setGmailToken(token);
      },
      () => {
        setGoogleUser(null);
        setGmailToken(null);
      }
    );
    return () => unsub();
  }, []);

  // Load Gmail messages when authenticated
  useEffect(() => {
    if (gmailToken) {
      fetchRecentGmailMessages(5).then(setGmailInbox);
    }
  }, [gmailToken]);

  // Language RTL / LTR handling
  useEffect(() => {
    localStorage.setItem('rst_erp_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Sync changes to Cloud DB and append Audit Log
  const syncDB = async (partial: any, logAction?: string, moduleName = 'ERP') => {
    if (!db) return;
    const newLogs = logAction
      ? [
          {
            id: Date.now(),
            time: new Date().toISOString(),
            user: currentUser?.username || 'admin',
            role: currentUser?.role || 'admin',
            action: logAction,
            module: moduleName,
            branch: currentUser?.branch || 'Mabellah Main Branch',
          },
          ...(db.auditLogs || []).slice(0, 299),
        ]
      : db.auditLogs;

    const nextState = {
      ...db,
      ...partial,
      auditLogs: newLogs,
    };
    setDb(nextState);

    await fetch('/api/state/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...partial, auditLogs: newLogs }),
    });
  };

  // Trigger Notification + Optional Gmail Dispatch Dialog
  const pushNotification = async (title: string, body: string, type = 'system') => {
    if (!db) return;
    const newNotif = {
      id: Date.now(),
      time: new Date().toISOString(),
      title,
      body,
      type,
      emailSent: false,
      read: false,
    };
    const updatedNotifs = [newNotif, ...(db.notifications || []).slice(0, 99)];
    await syncDB({ notifications: updatedNotifs });
    showToast(`${title}: ${body}`, 'info');
  };

  // Prompt confirmation before sending Gmail message (Workspace Skill Mandatory Rule)
  const requestGmailSend = (to: string, subject: string, htmlBody: string) => {
    setEmailConfirmModal({
      isOpen: true,
      to: to || db?.themeConfig?.email || 'assalatasom@gmail.com',
      subject,
      htmlBody,
    });
  };

  const confirmAndSendGmail = async () => {
    setSendingEmail(true);
    try {
      if (!gmailToken) {
        const signInRes = await googleSignIn();
        if (!signInRes) {
          showToast('Sign-in popup was closed before completing authentication.', 'info');
          return;
        }
        setGoogleUser(signInRes.user);
        setGmailToken(signInRes.accessToken);
      }
      const result = await sendGmailNotification(
        emailConfirmModal.to,
        emailConfirmModal.subject,
        emailConfirmModal.htmlBody
      );
      if (result.ok) {
        SoundEngine.success();
        showToast(`Gmail alert sent to ${emailConfirmModal.to}`, 'success');
        await syncDB(
          {},
          `Sent Gmail notification "${emailConfirmModal.subject}" to ${emailConfirmModal.to}`,
          'Gmail'
        );
      } else {
        SoundEngine.error();
        showToast(`Gmail error: ${result.error}`, 'error');
      }
    } catch (err: any) {
      showToast(`Gmail error: ${err?.message || 'Unable to send email'}`, 'error');
    } finally {
      setSendingEmail(false);
      setEmailConfirmModal({ isOpen: false, to: '', subject: '', htmlBody: '' });
    }
  };

  // Translation helper
  const t = (key: string, fallback?: string): string => {
    return db?.translations?.[lang]?.[key] || db?.translations?.en?.[key] || fallback || key;
  };

  // Generate Gemini Executive Intelligence Summary
  const generateExecutiveSummary = async () => {
    setLoadingAiSummary(true);
    SoundEngine.click();
    try {
      const res = await fetch('/api/gemini/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lang }),
      });
      const data = await res.json();
      if (data.summary) {
        setAiSummary(data.summary);
        SoundEngine.notify();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAiSummary(false);
    }
  };

  if (loading || !db) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">
        <div className="flex items-center gap-3 text-sm font-medium">
          <RefreshCw className="h-5 w-5 animate-spin text-emerald-400" />
          <span>Loading RST Electronics Oman Enterprise Cloud ERP...</span>
        </div>
      </div>
    );
  }

  const config = db.themeConfig || {};
  const decimals = config.decimalPlaces ?? 3;
  const fmt = (n: any) => Number(n || 0).toFixed(decimals);

  // Barcode scan callback handler
  const handleBarcodeScanned = (code: string) => {
    if (scannerModal.target === 'pos') {
      const matched = (db.products || []).find(
        (p: any) => !p.is_deleted && (p.barcode === code || p.imei === code || p.serialNo === code)
      );
      if (matched) {
        addToPosCart(matched);
        showToast(`Added ${matched.nameEn} (${code}) to POS Bill`, 'success');
      } else {
        showToast(`No product matched barcode/IMEI: ${code}`, 'error');
      }
    } else if (scannerModal.target === 'inventory') {
      setNewItem((prev) => ({ ...prev, barcode: code }));
      showToast(`Assigned scanned code ${code} to new item`, 'success');
    } else if (scannerModal.target === 'imei_lookup') {
      setScannedLookupCode(code);
      showToast(`Filtered inventory by code: ${code}`, 'info');
    }
  };

  // POS Cart Functions
  const addToPosCart = (product: any) => {
    SoundEngine.beep();
    setPosCart((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) {
          showToast(`Max available stock (${product.stock}) reached`, 'error');
          return prev;
        }
        return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.nameEn,
          barcode: product.barcode,
          imei: product.imei,
          price: Number(product.price),
          cost: Number(product.cost),
          qty: 1,
        },
      ];
    });
  };

  const posSubtotal = posCart.reduce((s, i) => s + i.price * i.qty, 0);
  const posDiscVal = parseFloat(posDiscount) || 0;
  const posTaxable = Math.max(0, posSubtotal - posDiscVal);
  const posVat = posTaxable * ((config.vatRate ?? 5) / 100);
  const posNetTotal = posTaxable + posVat;
  const posCashNum = parseFloat(posCashReceived) || posNetTotal;
  const posDue = Math.max(0, posNetTotal - posCashNum);

  const handlePosSaveAndPrint = async (format: 'a4' | 'thermal' = 'a4') => {
    if (!posCart.length) {
      showToast('POS Cart is empty! Scan a barcode or click an item.', 'error');
      return;
    }
    const cust = (db.customers || []).find((c: any) => c.id === Number(posCustomerId));
    const invNo = `RST-${String((db.invoices?.length || 0) + 1).padStart(5, '0')}`;
    const profit = posCart.reduce((s, i) => s + (i.price - i.cost) * i.qty, 0) - posDiscVal;

    const newInvoice = {
      id: Date.now(),
      invoice_no: invNo,
      date: new Date().toISOString(),
      customer: cust?.name || 'Walk-in Customer',
      customerId: cust?.id || 0,
      branch: currentUser?.branch || 'Mabellah Main Branch',
      items: posCart,
      subtotal: posSubtotal,
      discount: posDiscVal,
      vat: posVat,
      grand_total: posNetTotal,
      payment: posPayMode,
      profit,
      status: posDue > 0.001 ? 'Due' : 'Paid',
      operator: currentUser?.username || 'admin',
      is_deleted: false,
    };

    const updatedProducts = (db.products || []).map((p: any) => {
      const sold = posCart.find((i) => i.id === p.id);
      if (sold) {
        return { ...p, stock: Math.max(0, p.stock - sold.qty) };
      }
      return p;
    });

    const updatedCustomers = (db.customers || []).map((c: any) => {
      if (c.id === Number(posCustomerId)) {
        const nextSpent = Number(c.totalPurchases || 0) + posNetTotal;
        const nextSegment =
          nextSpent >= 2000
            ? 'VIP Platinum'
            : nextSpent >= 1000
            ? 'VIP Diamond'
            : nextSpent >= 500
            ? 'VIP Gold'
            : 'Regular';
        return {
          ...c,
          totalPurchases: nextSpent,
          loyaltyPoints: Math.floor(nextSpent),
          segment: nextSegment,
          balance: Number(c.balance || 0) + posDue,
        };
      }
      return c;
    });

    await syncDB(
      {
        invoices: [newInvoice, ...(db.invoices || [])],
        products: updatedProducts,
        customers: updatedCustomers,
      },
      `POS Sale ${invNo} (${fmt(posNetTotal)} ${config.currency})`,
      'POS'
    );

    await pushNotification(
      `POS Sale Completed (${invNo})`,
      `${newInvoice.customer} purchased ${posCart.length} item(s) for ${fmt(posNetTotal)} ${config.currency}.`,
      'sale'
    );

    SoundEngine.success();
    printTaxInvoice(newInvoice, config, format);
    setPosCart([]);
    setPosDiscount('0.000');
    setPosCashReceived('');
  };

  // Toggle Pin/Unpin Module on Dashboard & Sidebar
  const togglePinModule = async (modId: string) => {
    SoundEngine.click();
    const currentPins: string[] = db.pinnedModules || [];
    const nextPins = currentPins.includes(modId)
      ? currentPins.filter((m) => m !== modId)
      : [...currentPins, modId];
    await syncDB({ pinnedModules: nextPins }, `Updated pinned dashboard modules`, 'Admin');
  };

  // Simulate real-time Oman Telecom Network Ping / Latency Probe
  const runOmanNetworkLatencyProbe = async () => {
    setLatencySimulating(true);
    SoundEngine.beep();
    setTimeout(async () => {
      const updatedOps = (db.telecomOperators || []).map((op: any) => {
        const jitter = Math.floor(Math.random() * 7) - 3;
        const nextLatency = Math.max(7, Number(op.latencyMs || 18) + jitter);
        return {
          ...op,
          latencyMs: nextLatency,
          status: nextLatency < 24 ? 'Optimal' : 'Nominal',
        };
      });
      await syncDB({ telecomOperators: updatedOps }, 'Executed Oman Telecom Network Latency Probe', 'Telecom');
      setLatencySimulating(false);
      showToast('Oman Telecom gateway latency & packet telemetry refreshed', 'success');
    }, 450);
  };

  // All ERP Navigation Modules
  const ALL_MODULES = [
    { id: 'dashboard', label: t('dashboard', 'Executive Dashboard'), icon: LayoutDashboard },
    { id: 'pos', label: t('pos_sales', 'POS & Barcode Billing'), icon: ShoppingCart },
    { id: 'inventory', label: t('inventory', 'Inventory & IMEI Hub'), icon: Package },
    { id: 'telecom', label: t('telecom_oman', 'Oman Telecom & Latency'), icon: Radio },
    { id: 'repairs', label: t('repairs_cctv', 'Repairs, CCTV & Expenses'), icon: Wrench },
    { id: 'offers', label: t('offers_engine', 'Offers & Plan Comparison'), icon: Sparkles },
    { id: 'vip', label: t('vip_crm', 'VIP Loyalty & Branches'), icon: Crown },
    { id: 'employees', label: t('employees_hr', 'Employees & Payroll'), icon: Users },
    { id: 'reports', label: t('reports_analytics', 'Financial Reports & Export'), icon: FileSpreadsheet },
    { id: 'security', label: t('security_rbac', 'Roles, Logs & Gmail Alerts'), icon: ShieldAlert },
    { id: 'theme', label: t('theme_lang', 'Theme, Sound & Languages'), icon: Palette },
    { id: 'master_editor', label: t('master_editor', 'Admin Master Data Editor'), icon: Sliders },
  ];

  // Filter modules based on currentUser role permissions
  const visibleModules = ALL_MODULES.filter((m) => {
    if (!currentUser) return true;
    if (currentUser.role === 'admin') return true;
    if (currentUser.role === 'dealer') return ['telecom', 'offers'].includes(m.id);
    return (currentUser.permissions || []).includes('all') || (currentUser.permissions || []).includes(m.id);
  });

  // KPI Metrics Calculation
  const totalSalesRevenue = (db.invoices || []).reduce((s: number, i: any) => s + Number(i.grand_total || 0), 0);
  const totalRetailProfit = (db.invoices || []).reduce((s: number, i: any) => s + Number(i.profit || 0), 0);
  const totalTelecomProfit = (db.telecomTransactions || []).reduce((s: number, tx: any) => s + Number(tx.profit || 0), 0);
  const totalUtilityProfit = (db.utilityTransactions || []).reduce((s: number, tx: any) => s + Number(tx.profit || 0), 0);
  const combinedNetProfit = totalRetailProfit + totalTelecomProfit + totalUtilityProfit;
  const totalTelecomPool = (db.telecomOperators || []).reduce((s: number, o: any) => s + Number(o.balance || 0), 0);
  const totalInventoryValuation = (db.products || [])
    .filter((p: any) => !p.is_deleted)
    .reduce((s: number, p: any) => s + Number(p.cost || 0) * Number(p.stock || 0), 0);

  return (
    <div
      className="min-h-screen bg-slate-50 text-slate-900 flex flex-col"
      style={{ '--erp-primary': config.primaryColor || '#059669' } as React.CSSProperties}
    >
      {/* Top Bar Contract: Zone 1 Brand, Zone 2 Concise Nav Links, Zone 3 Primary Action */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-950 text-white border-b border-slate-800">
        {/* Zone 1: Single Text Element Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setViewMode('erp');
            setActiveModule('dashboard');
          }}
          className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          {config.businessName || 'RST ELECTRONICS'}
        </a>

        {/* Zone 2: 5 Concise Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <button
            onClick={() => {
              SoundEngine.click();
              setViewMode('erp');
              setActiveModule('dashboard');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              viewMode === 'erp' && activeModule === 'dashboard' ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            {t('dashboard', 'Dashboard')}
          </button>
          <button
            onClick={() => {
              SoundEngine.click();
              setViewMode('erp');
              setActiveModule('pos');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              viewMode === 'erp' && activeModule === 'pos' ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            {t('pos_sales', 'POS Billing')}
          </button>
          <button
            onClick={() => {
              SoundEngine.click();
              setViewMode('erp');
              setActiveModule('telecom');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              viewMode === 'erp' && activeModule === 'telecom' ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            {t('telecom_oman', 'Oman Telecom')}
          </button>
          <button
            onClick={() => {
              SoundEngine.click();
              setViewMode('erp');
              setActiveModule('reports');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              viewMode === 'erp' && activeModule === 'reports' ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            {t('reports_analytics', 'Reports')}
          </button>
          <button
            onClick={() => {
              SoundEngine.click();
              setViewMode(viewMode === 'storefront' ? 'erp' : 'storefront');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              viewMode === 'storefront' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            {viewMode === 'storefront' ? t('erp_console', 'ERP Console') : t('storefront', 'Live Storefront')}
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setScannerModal({ isOpen: true, target: 'pos' })}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
          >
            <ScanBarcode className="h-4 w-4" />
            <span>{t('scan_barcode', 'Scan Barcode / IMEI')}</span>
          </button>
        </div>
      </header>

      {/* Sub-Toolbar: Multi-Language Switcher (EN/BN/AR), Active Role Switcher, Sound Toggle & Gmail Auth */}
      <div className="bg-white border-b border-slate-200 px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* Language Switcher */}
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
            {(
              [
                { code: 'en', label: 'EN · English' },
                { code: 'bn', label: 'BN · বাংলা' },
                { code: 'ar', label: 'AR · العربية' },
              ] as const
            ).map((l) => (
              <button
                key={l.code}
                onClick={() => {
                  SoundEngine.click();
                  setLang(l.code);
                }}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  lang === l.code
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>

          {/* Role / Staff Switcher for Demo & Testing */}
          <div className="flex items-center gap-2 text-slate-600">
            <span className="font-medium">Active Role:</span>
            <select
              value={currentUser?.id || 1}
              onChange={(e) => {
                const u = (db.users || []).find((x: any) => x.id === Number(e.target.value));
                if (u) {
                  SoundEngine.click();
                  setCurrentUser(u);
                  if (u.role === 'dealer') setActiveModule('telecom');
                  showToast(`Switched active session to ${u.fullname} (${u.role.toUpperCase()})`, 'info');
                }
              }}
              className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-900"
            >
              {(db.users || []).map((u: any) => (
                <option key={u.id} value={u.id}>
                  {u.fullname} ({u.role.toUpperCase()} · {u.branch})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Right Controls: Sound Toggle + Google Workspace Gmail Connection */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const nextSound = !config.soundEnabled;
              SoundEngine.enabled = nextSound;
              if (nextSound) SoundEngine.beep();
              syncDB({ themeConfig: { ...config, soundEnabled: nextSound } });
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
          >
            {config.soundEnabled ? (
              <>
                <Volume2 className="h-3.5 w-3.5 text-emerald-600" />
                <span>Audio ON</span>
              </>
            ) : (
              <>
                <VolumeX className="h-3.5 w-3.5 text-slate-400" />
                <span>Audio Muted</span>
              </>
            )}
          </button>

          {gmailToken ? (
            <div className="flex items-center gap-2">
              <span className="text-slate-600">
                Gmail Connected: <strong className="text-slate-900">{googleUser?.email}</strong>
              </span>
              <button
                onClick={() =>
                  requestGmailSend(
                    config.email || 'assalatasom@gmail.com',
                    `RST Electronics ERP Live Financial Report (${new Date().toLocaleDateString()})`,
                    `<h2>${config.businessName} — Executive Summary</h2>
                    <p><strong>Total Sales Revenue:</strong> ${fmt(totalSalesRevenue)} ${config.currency}</p>
                    <p><strong>Combined Net Profit:</strong> ${fmt(combinedNetProfit)} ${config.currency}</p>
                    <p><strong>Oman Telecom Dealer Pool:</strong> ${fmt(totalTelecomPool)} ${config.currency}</p>
                    <p><strong>Active Inventory Valuation:</strong> ${fmt(totalInventoryValuation)} ${config.currency}</p>`
                  )
                }
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 whitespace-nowrap shrink-0"
              >
                <Mail className="h-3.5 w-3.5" />
                <span>Email Admin Report</span>
              </button>
              <button
                onClick={logoutGoogle}
                className="text-xs text-slate-400 hover:text-rose-600"
              >
                Disconnect
              </button>
            </div>
          ) : (
            <button
              onClick={async () => {
                try {
                  const res = await googleSignIn();
                  if (res) {
                    setGoogleUser(res.user);
                    setGmailToken(res.accessToken);
                    showToast(`Connected Gmail: ${res.user.email}`, 'success');
                  } else {
                    showToast('Google Sign-In popup closed before completing.', 'info');
                  }
                } catch (err: any) {
                  showToast(`Google Sign-In failed: ${err?.message || 'Unable to authenticate'}`, 'error');
                }
              }}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-1 text-xs font-semibold text-slate-800 hover:bg-slate-50 shadow-2xs whitespace-nowrap shrink-0"
            >
              <Mail className="h-3.5 w-3.5 text-rose-600" />
              <span>Sign in with Google (Gmail Alerts)</span>
            </button>
          )}
        </div>
      </div>

      {/* Toast Alert Banner */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 max-w-md rounded-xl border border-slate-200 bg-slate-900 px-4 py-3 text-xs font-medium text-white shadow-xl flex items-center gap-2.5">
          <Check className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Main Viewport Switch: Live Public Storefront vs Enterprise ERP Console */}
      {viewMode === 'storefront' ? (
        <StorefrontView
          db={db}
          lang={lang}
          t={t}
          onSyncDB={syncDB}
          onNotify={pushNotification}
          onSwitchToErp={() => setViewMode('erp')}
        />
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row">
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-64 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 shrink-0 p-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="px-2">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  {config.legalName}
                </div>
                <div className="text-xs text-slate-500 mt-0.5">
                  CR {config.crNo} · {currentUser?.branch || 'Mabellah Main'}
                </div>
              </div>

              <div className="space-y-1">
                {visibleModules.map((mod) => {
                  const Icon = mod.icon;
                  const isPinned = (db.pinnedModules || []).includes(mod.id);
                  const isActive = activeModule === mod.id;
                  return (
                    <div key={mod.id} className="group flex items-center gap-1">
                      <button
                        onClick={() => {
                          SoundEngine.click();
                          setActiveModule(mod.id);
                        }}
                        className={`flex-1 flex items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap overflow-hidden ${
                          isActive
                            ? 'bg-slate-900 text-white'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                        <span className="truncate">{mod.label}</span>
                      </button>
                      {currentUser?.role === 'admin' && (
                        <button
                          onClick={() => togglePinModule(mod.id)}
                          title={isPinned ? 'Unpin from Dashboard' : 'Pin to Dashboard'}
                          className={`p-1.5 rounded-md text-xs transition-opacity ${
                            isPinned
                              ? 'text-amber-600 opacity-100'
                              : 'text-slate-400 opacity-0 group-hover:opacity-100 hover:text-slate-700'
                          }`}
                        >
                          {isPinned ? <Pin className="h-3.5 w-3.5" /> : <PinOff className="h-3.5 w-3.5" />}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200 space-y-2">
              <button
                onClick={() => setViewMode('storefront')}
                className="w-full flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100 transition-colors"
              >
                <Store className="h-4 w-4 text-emerald-600" />
                <span>Open Public Storefront</span>
              </button>
            </div>
          </aside>

          {/* Main ERP Workspace Content */}
          <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto w-full space-y-6">
            {/* ==================== 1. EXECUTIVE DASHBOARD ==================== */}
            {activeModule === 'dashboard' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h1 className="text-2xl font-bold tracking-tight text-slate-950">
                      {t('dashboard', 'Executive ERP & Oman Telecom Dashboard')}
                    </h1>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Real-time cloud-synchronized telemetry · {config.address} · Currency: {config.currency}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={generateExecutiveSummary}
                      disabled={loadingAiSummary}
                      className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                      <span>
                        {loadingAiSummary ? 'Generating AI Insights...' : 'Gemini Executive Summary'}
                      </span>
                    </button>
                    <button
                      onClick={() => setActiveModule('pos')}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
                    >
                      <Plus className="h-4 w-4" />
                      <span>New POS Sale</span>
                    </button>
                  </div>
                </div>

                {/* Gemini Automated Executive Summary Box */}
                {aiSummary && (
                  <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 text-xs text-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between font-bold text-emerald-900">
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="h-4 w-4 text-emerald-600" />
                        Gemini 3.8 Automated Financial & Inventory Intelligence
                      </span>
                      <button
                        onClick={() => setAiSummary('')}
                        className="text-slate-400 hover:text-slate-700"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="whitespace-pre-wrap leading-relaxed">{aiSummary}</div>
                  </div>
                )}

                {/* 4-Column KPI Strip */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="rounded-xl border border-slate-200 bg-white p-5">
                    <div className="text-xs font-medium text-slate-500">
                      {t('total_revenue', 'Total Sales Revenue')}
                    </div>
                    <div className="text-2xl font-bold font-mono text-slate-950 mt-1 tabular-nums">
                      {fmt(totalSalesRevenue)} <span className="text-xs font-normal">{config.currency}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-2">
                      {db.invoices?.length || 0} Tax Invoices · VAT {config.vatRate}%
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-200 bg-white p-5">
                    <div className="text-xs font-medium text-slate-500">
                      {t('net_profit', 'Combined Net Profit Margin')}
                    </div>
                    <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
                      {fmt(combinedNetProfit)} <span className="text-xs font-normal">{config.currency}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-2">
                      Retail: {fmt(totalRetailProfit)} · Telecom: {fmt(totalTelecomProfit)}
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-200 bg-white p-5">
                    <div className="text-xs font-medium text-slate-500">
                      {t('telecom_pool', 'Oman Telecom Dealer Pool')}
                    </div>
                    <div className="text-2xl font-bold font-mono text-slate-950 mt-1 tabular-nums">
                      {fmt(totalTelecomPool)} <span className="text-xs font-normal">{config.currency}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-2">
                      6 Active Operators · Avg Latency 19ms
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-200 bg-white p-5">
                    <div className="text-xs font-medium text-slate-500">
                      {t('active_inventory', 'Active Inventory Valuation')}
                    </div>
                    <div className="text-2xl font-bold font-mono text-slate-950 mt-1 tabular-nums">
                      {fmt(totalInventoryValuation)} <span className="text-xs font-normal">{config.currency}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-2">
                      {db.products?.filter((p: any) => !p.is_deleted).length || 0} SKUs Tracked by Barcode/IMEI
                    </div>
                  </div>
                </div>

                {/* Pinned Quick-Launch Categories (Admin Customizable Pin/Unpin) */}
                <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">
                        Pinned Workspace Categories (Admin Customizable)
                      </h2>
                      <p className="text-xs text-slate-500">
                        Click the pin icon on any module or below to pin/unpin quick-access operational workflows.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {ALL_MODULES.filter((m) => (db.pinnedModules || []).includes(m.id)).map((mod) => {
                      const Icon = mod.icon;
                      return (
                        <div
                          key={mod.id}
                          className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50/70 px-3.5 py-3 hover:border-emerald-500 hover:bg-white transition-all"
                        >
                          <button
                            onClick={() => setActiveModule(mod.id)}
                            className="flex items-center gap-2.5 text-left flex-1 min-w-0"
                          >
                            <Icon className="h-4 w-4 text-emerald-600 shrink-0" />
                            <span className="text-xs font-semibold text-slate-900 truncate">
                              {mod.label}
                            </span>
                          </button>
                          <button
                            onClick={() => togglePinModule(mod.id)}
                            className="text-amber-600 hover:text-slate-400 ml-2 shrink-0"
                            title="Unpin module"
                          >
                            <Pin className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Recent Invoices & Oman Telecom Live Status */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900">Recent POS & Online Tax Invoices</h3>
                      <button
                        onClick={() => setActiveModule('reports')}
                        className="text-xs font-semibold text-emerald-700 hover:underline"
                      >
                        View All & Export CSV →
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-500">
                            <th className="py-2.5 px-3">Invoice</th>
                            <th className="py-2.5 px-3">Customer</th>
                            <th className="py-2.5 px-3">Branch</th>
                            <th className="py-2.5 px-3 text-right">Net Total</th>
                            <th className="py-2.5 px-3 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(db.invoices || []).slice(0, 5).map((inv: any) => (
                            <tr key={inv.id} className="hover:bg-slate-50">
                              <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                                {inv.invoice_no}
                              </td>
                              <td className="py-2.5 px-3">{inv.customer}</td>
                              <td className="py-2.5 px-3 text-slate-500">{inv.branch}</td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                                {fmt(inv.grand_total)} {config.currency}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <button
                                  onClick={() => printTaxInvoice(inv, config, 'a4')}
                                  className="inline-flex items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium hover:bg-slate-100"
                                >
                                  <Printer className="h-3 w-3" /> Print A4
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900">
                        Oman Telecom Margin & Latency Telemetry
                      </h3>
                      <button
                        onClick={runOmanNetworkLatencyProbe}
                        disabled={latencySimulating}
                        className="text-xs font-semibold text-emerald-700 hover:underline"
                      >
                        {latencySimulating ? 'Pinging...' : 'Ping Gateways'}
                      </button>
                    </div>
                    <div className="space-y-2.5">
                      {(db.telecomOperators || []).map((op: any) => (
                        <div
                          key={op.id}
                          className="flex items-center justify-between rounded-lg border border-slate-200 px-3.5 py-2.5 text-xs"
                        >
                          <div>
                            <div className="font-semibold text-slate-900">{op.name}</div>
                            <div className="text-[11px] text-slate-500">
                              Margin:{' '}
                              {op.commissionType === 'percent'
                                ? `${op.commissionValue}%`
                                : `${fmt(op.commissionValue)} OMR`}{' '}
                              · Latency: <span className="font-mono">{op.latencyMs}ms</span>
                            </div>
                          </div>
                          <div className="text-right font-mono">
                            <div className="font-bold text-slate-900 tabular-nums">
                              {fmt(op.balance)} {config.currency}
                            </div>
                            <div className="text-[11px] text-emerald-700">{op.reliability}% SLA</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 2. POS & BARCODE BILLING ==================== */}
            {activeModule === 'pos' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      {t('pos_sales', 'POS Sales & Barcode / IMEI Billing Counter')}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Scan Barcode, QR, or 15-digit IMEI · Automatic 5% Oman VAT · Instant A4 & Thermal Print
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setScannerModal({ isOpen: true, target: 'pos' })}
                      className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      <ScanBarcode className="h-4 w-4" />
                      <span>Launch Camera Barcode/IMEI Scanner</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left 7 Cols: Product Selector & Cart Table */}
                  <div className="lg:col-span-7 space-y-4">
                    <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={posSearch}
                            onChange={(e) => setPosSearch(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && posSearch.trim()) {
                                const exact = (db.products || []).find(
                                  (p: any) =>
                                    !p.is_deleted &&
                                    (p.barcode === posSearch.trim() ||
                                      p.imei === posSearch.trim() ||
                                      p.serialNo === posSearch.trim())
                                );
                                if (exact) {
                                  addToPosCart(exact);
                                  setPosSearch('');
                                }
                              }
                            }}
                            placeholder="Scan Barcode / IMEI here or search item name (Press Enter)..."
                            className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-xs font-mono focus:border-emerald-600 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-64 overflow-y-auto pt-1">
                        {(db.products || [])
                          .filter(
                            (p: any) =>
                              !p.is_deleted &&
                              p.stock > 0 &&
                              (!posSearch ||
                                (p.nameEn || '').toLowerCase().includes(posSearch.toLowerCase()) ||
                                (p.barcode || '').includes(posSearch) ||
                                (p.imei || '').includes(posSearch))
                          )
                          .map((p: any) => (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => addToPosCart(p)}
                              className="rounded-lg border border-slate-200 p-3 text-left hover:border-emerald-600 hover:bg-emerald-50/40 transition-all"
                            >
                              <div className="text-xs font-bold text-slate-900 truncate">
                                {lang === 'bn' ? p.nameBn || p.nameEn : lang === 'ar' ? p.nameAr || p.nameEn : p.nameEn}
                              </div>
                              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                                {p.barcode}
                              </div>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-xs font-mono font-bold text-emerald-700">
                                  {fmt(p.price)} {config.currency}
                                </span>
                                <span className="text-[10px] font-mono text-slate-500">
                                  Qty: {p.stock}
                                </span>
                              </div>
                            </button>
                          ))}
                      </div>
                    </div>

                    {/* POS Cart Items Table */}
                    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                            <th className="py-2.5 px-3">Item / Barcode / IMEI</th>
                            <th className="py-2.5 px-3 text-right">Unit Price</th>
                            <th className="py-2.5 px-3 text-center">Qty</th>
                            <th className="py-2.5 px-3 text-right">Amount</th>
                            <th className="py-2.5 px-3"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {posCart.length === 0 ? (
                            <tr>
                              <td colSpan={5} className="py-8 text-center text-slate-400">
                                No items in bill. Scan a barcode/IMEI or select a product above.
                              </td>
                            </tr>
                          ) : (
                            posCart.map((item, idx) => (
                              <tr key={item.id}>
                                <td className="py-2.5 px-3">
                                  <div className="font-semibold text-slate-900">{item.name}</div>
                                  <div className="text-[11px] font-mono text-slate-500">
                                    Code: {item.barcode} {item.imei ? `· IMEI: ${item.imei}` : ''}
                                  </div>
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                                  {fmt(item.price)}
                                </td>
                                <td className="py-2.5 px-3 text-center">
                                  <input
                                    type="number"
                                    min={1}
                                    value={item.qty}
                                    onChange={(e) => {
                                      const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                                      setPosCart((prev) =>
                                        prev.map((x, i) => (i === idx ? { ...x, qty: val } : x))
                                      );
                                    }}
                                    className="w-16 rounded border border-slate-300 px-2 py-1 text-center font-mono text-xs"
                                  />
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                                  {fmt(item.price * item.qty)}
                                </td>
                                <td className="py-2.5 px-3 text-right">
                                  <button
                                    onClick={() =>
                                      setPosCart((prev) => prev.filter((_, i) => i !== idx))
                                    }
                                    className="text-rose-600 hover:text-rose-800"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Right 5 Cols: Bill Calculation & Print */}
                  <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-4 h-fit">
                    <h3 className="text-base font-bold text-slate-900 border-b border-slate-200 pb-3">
                      Invoice Settlement & Print
                    </h3>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Select VIP / Registered Customer
                      </label>
                      <select
                        value={posCustomerId}
                        onChange={(e) => setPosCustomerId(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                      >
                        {(db.customers || []).map((c: any) => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.segment} · {c.phone})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Discount ({config.currency})
                        </label>
                        <input
                          type="number"
                          step="0.001"
                          value={posDiscount}
                          onChange={(e) => setPosDiscount(e.target.value)}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Payment Mode
                        </label>
                        <select
                          value={posPayMode}
                          onChange={(e) => setPosPayMode(e.target.value)}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        >
                          <option value="Cash">Cash (OMR)</option>
                          <option value="Card">Visa / MasterCard / OmanNet</option>
                          <option value="Bank Transfer">Bank Muscat Transfer</option>
                          <option value="Credit / Due">VIP Credit Ledger</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Cash Received ({config.currency})
                      </label>
                      <input
                        type="number"
                        step="0.001"
                        value={posCashReceived}
                        onChange={(e) => setPosCashReceived(e.target.value)}
                        placeholder={fmt(posNetTotal)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>

                    <div className="rounded-lg bg-slate-50 p-4 space-y-2 text-xs border border-slate-200">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Subtotal:</span>
                        <span className="font-mono font-semibold">{fmt(posSubtotal)} {config.currency}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Discount:</span>
                        <span className="font-mono text-rose-600">-{fmt(posDiscVal)} {config.currency}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Oman VAT ({config.vatRate}%):</span>
                        <span className="font-mono">{fmt(posVat)} {config.currency}</span>
                      </div>
                      <div className="flex justify-between text-base font-bold text-slate-950 pt-2 border-t border-slate-200">
                        <span>Net Total:</span>
                        <span className="font-mono text-emerald-700">{fmt(posNetTotal)} {config.currency}</span>
                      </div>
                      {posDue > 0.001 && (
                        <div className="flex justify-between text-xs font-semibold text-rose-600">
                          <span>Balance Due:</span>
                          <span className="font-mono">{fmt(posDue)} {config.currency}</span>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => handlePosSaveAndPrint('a4')}
                        className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors"
                      >
                        <Printer className="h-4 w-4" />
                        <span>Save & A4 Invoice</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handlePosSaveAndPrint('thermal')}
                        className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors"
                      >
                        <Printer className="h-4 w-4" />
                        <span>80mm Thermal Receipt</span>
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (!posCart.length) return;
                          setPosHeldOrders((prev) => [
                            ...prev,
                            { id: Date.now(), time: new Date().toLocaleTimeString(), items: posCart },
                          ]);
                          setPosCart([]);
                          showToast('Order placed on hold', 'info');
                        }}
                        className="flex-1 rounded-lg border border-slate-300 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        Hold Bill ({posHeldOrders.length})
                      </button>
                      {posHeldOrders.length > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            const last = posHeldOrders[posHeldOrders.length - 1];
                            setPosCart(last.items);
                            setPosHeldOrders((prev) => prev.slice(0, -1));
                            showToast('Restored held bill', 'info');
                          }}
                          className="flex-1 rounded-lg border border-amber-300 bg-amber-50 py-2 text-xs font-semibold text-amber-900"
                        >
                          Restore Held
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 3. INVENTORY, BARCODE & IMEI HUB ==================== */}
            {activeModule === 'inventory' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      {t('inventory', 'Inventory, Categories, Barcode & IMEI Serial Hub')}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Every device is tracked by EAN-13 Barcode, 15-Digit IMEI, and Serial Number across Oman branches.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 rounded-lg bg-slate-200/80 p-1">
                    {(
                      [
                        { id: 'list', label: 'Product & IMEI List' },
                        { id: 'add', label: '+ Add New Device/Item' },
                        { id: 'barcode', label: 'Barcode Studio & Categories' },
                        { id: 'transfer', label: 'Branch Stock Transfer' },
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setInvTab(tab.id)}
                        className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                          invTab === tab.id
                            ? 'bg-white text-slate-950 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                {invTab === 'list' && (
                  <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2 flex-1 max-w-md">
                        <input
                          type="text"
                          value={scannedLookupCode}
                          onChange={(e) => setScannedLookupCode(e.target.value)}
                          placeholder="Filter by Barcode, IMEI, Serial No, or Brand..."
                          className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-mono"
                        />
                        <button
                          onClick={() => setScannerModal({ isOpen: true, target: 'imei_lookup' })}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white whitespace-nowrap shrink-0"
                        >
                          <ScanBarcode className="h-4 w-4" /> Scan Lookup
                        </button>
                      </div>
                      <button
                        onClick={() =>
                          exportToExcelCSV(
                            'RST_Inventory_IMEI_Stock',
                            ['ID', 'Name (EN)', 'Category', 'Brand', 'Barcode', 'IMEI', 'SerialNo', 'Cost OMR', 'Price OMR', 'Stock'],
                            (db.products || [])
                              .filter((p: any) => !p.is_deleted)
                              .map((p: any) => [
                                p.id,
                                p.nameEn,
                                p.category,
                                p.brand,
                                p.barcode,
                                p.imei || '-',
                                p.serialNo || '-',
                                fmt(p.cost),
                                fmt(p.price),
                                p.stock,
                              ])
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                      >
                        <Download className="h-3.5 w-3.5" /> Export Excel CSV
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                            <th className="py-2.5 px-3">Product Name (EN / BN / AR)</th>
                            <th className="py-2.5 px-3">Category & Brand</th>
                            <th className="py-2.5 px-3">Barcode / IMEI / S/N</th>
                            <th className="py-2.5 px-3 text-right">Cost</th>
                            <th className="py-2.5 px-3 text-right">Sale Price</th>
                            <th className="py-2.5 px-3 text-center">Stock</th>
                            <th className="py-2.5 px-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(db.products || [])
                            .filter((p: any) => {
                              if (p.is_deleted) return false;
                              if (!scannedLookupCode) return true;
                              const q = scannedLookupCode.toLowerCase();
                              return (
                                (p.nameEn || '').toLowerCase().includes(q) ||
                                (p.barcode || '').toLowerCase().includes(q) ||
                                (p.imei || '').toLowerCase().includes(q) ||
                                (p.serialNo || '').toLowerCase().includes(q) ||
                                (p.brand || '').toLowerCase().includes(q)
                              );
                            })
                            .map((p: any) => (
                              <tr key={p.id} className="hover:bg-slate-50">
                                <td className="py-2.5 px-3">
                                  <div className="font-bold text-slate-900">{p.nameEn}</div>
                                  <div className="text-[11px] text-slate-500">
                                    {p.nameBn} · {p.nameAr}
                                  </div>
                                </td>
                                <td className="py-2.5 px-3">
                                  {p.category} · {p.brand}
                                </td>
                                <td className="py-2.5 px-3 font-mono text-[11px]">
                                  <div>BC: {p.barcode}</div>
                                  {p.imei && <div className="text-emerald-700">IMEI: {p.imei}</div>}
                                  {p.serialNo && <div className="text-slate-500">SN: {p.serialNo}</div>}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                                  {fmt(p.cost)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                                  {fmt(p.price)}
                                </td>
                                <td className="py-2.5 px-3 text-center font-mono font-bold">
                                  {p.stock} {p.unit}
                                </td>
                                <td className="py-2.5 px-3 text-right space-x-2">
                                  <button
                                    onClick={() => {
                                      setCustomBarcodeValue(p.barcode);
                                      setInvTab('barcode');
                                    }}
                                    className="text-emerald-700 hover:underline font-medium"
                                  >
                                    Barcode
                                  </button>
                                  <button
                                    onClick={async () => {
                                      const updated = (db.products || []).map((x: any) =>
                                        x.id === p.id ? { ...x, is_deleted: true } : x
                                      );
                                      await syncDB({ products: updated }, `Deleted product ${p.nameEn}`, 'Inventory');
                                    }}
                                    className="text-rose-600 hover:underline"
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {invTab === 'add' && (
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (!newItem.nameEn.trim()) return;
                      const created = {
                        id: Date.now(),
                        ...newItem,
                        cost: parseFloat(newItem.cost) || 0,
                        price: parseFloat(newItem.price) || 0,
                        wholesale: parseFloat(newItem.wholesale) || 0,
                        stock: parseInt(newItem.stock, 10) || 0,
                        active: true,
                        is_deleted: false,
                      };
                      await syncDB(
                        { products: [created, ...(db.products || [])] },
                        `Added new inventory item ${created.nameEn} (Barcode: ${created.barcode}, IMEI: ${created.imei})`,
                        'Inventory'
                      );
                      await pushNotification(
                        'New Inventory Item Added',
                        `${created.nameEn} (${created.stock} ${created.unit}) added with Barcode ${created.barcode}.`,
                        'inventory'
                      );
                      SoundEngine.success();
                      setInvTab('list');
                    }}
                    className="rounded-xl border border-slate-200 bg-white p-6 space-y-5"
                  >
                    <h3 className="text-base font-bold text-slate-900">
                      Add Tri-Language Product with Barcode, IMEI & Serial Number
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Product Name (English) *
                        </label>
                        <input
                          type="text"
                          required
                          value={newItem.nameEn}
                          onChange={(e) => setNewItem({ ...newItem, nameEn: e.target.value })}
                          placeholder="e.g. iPhone 16 Pro 256GB"
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          পণ্যের নাম (বাংলা)
                        </label>
                        <input
                          type="text"
                          value={newItem.nameBn}
                          onChange={(e) => setNewItem({ ...newItem, nameBn: e.target.value })}
                          placeholder="আইফোন ১৬ প্রো ২৫৬জিবি"
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          اسم المنتج (العربية)
                        </label>
                        <input
                          type="text"
                          value={newItem.nameAr}
                          onChange={(e) => setNewItem({ ...newItem, nameAr: e.target.value })}
                          placeholder="آيفون ١٦ برو ٢٥٦ جيجا"
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Barcode (EAN-13) *
                        </label>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            required
                            value={newItem.barcode}
                            onChange={(e) => setNewItem({ ...newItem, barcode: e.target.value })}
                            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setNewItem({ ...newItem, barcode: generateEAN13() })}
                            className="rounded-lg border border-slate-300 px-2.5 text-xs hover:bg-slate-100"
                          >
                            Auto
                          </button>
                          <button
                            type="button"
                            onClick={() => setScannerModal({ isOpen: true, target: 'inventory' })}
                            className="rounded-lg bg-emerald-600 px-2.5 text-xs text-white"
                          >
                            Scan
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          15-Digit IMEI Number
                        </label>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            value={newItem.imei}
                            onChange={(e) => setNewItem({ ...newItem, imei: e.target.value })}
                            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setNewItem({ ...newItem, imei: generateIMEI() })}
                            className="rounded-lg border border-slate-300 px-2.5 text-xs hover:bg-slate-100"
                          >
                            Auto IMEI
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Serial Number (SL NO)
                        </label>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            value={newItem.serialNo}
                            onChange={(e) => setNewItem({ ...newItem, serialNo: e.target.value })}
                            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setNewItem({ ...newItem, serialNo: generateSerialNo() })}
                            className="rounded-lg border border-slate-300 px-2.5 text-xs hover:bg-slate-100"
                          >
                            Auto SN
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                        <select
                          value={newItem.category}
                          onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        >
                          {(db.categories || []).map((c: any) => (
                            <option key={c.id} value={c.name}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Brand</label>
                        <input
                          type="text"
                          value={newItem.brand}
                          onChange={(e) => setNewItem({ ...newItem, brand: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Purchase Cost ({config.currency})
                        </label>
                        <input
                          type="number"
                          step="0.001"
                          value={newItem.cost}
                          onChange={(e) => setNewItem({ ...newItem, cost: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Sales Price ({config.currency})
                        </label>
                        <input
                          type="number"
                          step="0.001"
                          value={newItem.price}
                          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Wholesale Price ({config.currency})
                        </label>
                        <input
                          type="number"
                          step="0.001"
                          value={newItem.wholesale}
                          onChange={(e) => setNewItem({ ...newItem, wholesale: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Opening Stock
                        </label>
                        <input
                          type="number"
                          value={newItem.stock}
                          onChange={(e) => setNewItem({ ...newItem, stock: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Unit</label>
                        <select
                          value={newItem.unit}
                          onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        >
                          {(db.units || []).map((u: any) => (
                            <option key={u.id} value={u.name}>
                              {u.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Warranty</label>
                        <input
                          type="text"
                          value={newItem.warranty}
                          onChange={(e) => setNewItem({ ...newItem, warranty: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="rounded-lg bg-emerald-600 px-6 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      Save Item to Cloud Inventory
                    </button>
                  </form>
                )}

                {invTab === 'barcode' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                      <h3 className="text-sm font-bold text-slate-900">
                        Barcode Label Generator & Printer
                      </h3>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customBarcodeValue}
                          onChange={(e) => setCustomBarcodeValue(e.target.value)}
                          className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => setCustomBarcodeValue(generateEAN13())}
                          className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold"
                        >
                          New EAN-13
                        </button>
                      </div>
                      <div className="py-4 flex justify-center bg-slate-50 rounded-lg border border-slate-200">
                        <BarcodePreview value={customBarcodeValue} />
                      </div>
                    </div>

                    <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                      <h3 className="text-sm font-bold text-slate-900">
                        Editable Product Categories (EN / BN / AR)
                      </h3>
                      <form
                        onSubmit={async (e) => {
                          e.preventDefault();
                          if (!newCategoryName.trim()) return;
                          const nextCats = [
                            ...(db.categories || []),
                            {
                              id: Date.now(),
                              name: newCategoryName.trim(),
                              nameBn: newCategoryBn.trim() || newCategoryName.trim(),
                              nameAr: newCategoryAr.trim() || newCategoryName.trim(),
                            },
                          ];
                          await syncDB({ categories: nextCats }, `Added category ${newCategoryName}`, 'Inventory');
                          setNewCategoryName('');
                          setNewCategoryBn('');
                          setNewCategoryAr('');
                        }}
                        className="grid grid-cols-1 sm:grid-cols-4 gap-2"
                      >
                        <input
                          type="text"
                          value={newCategoryName}
                          onChange={(e) => setNewCategoryName(e.target.value)}
                          placeholder="Name (EN)"
                          className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
                        />
                        <input
                          type="text"
                          value={newCategoryBn}
                          onChange={(e) => setNewCategoryBn(e.target.value)}
                          placeholder="বাংলা নাম"
                          className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
                        />
                        <input
                          type="text"
                          value={newCategoryAr}
                          onChange={(e) => setNewCategoryAr(e.target.value)}
                          placeholder="الاسم بالعربية"
                          className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
                        />
                        <button
                          type="submit"
                          className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white"
                        >
                          + Add
                        </button>
                      </form>

                      <div className="divide-y divide-slate-200 text-xs max-h-56 overflow-y-auto">
                        {(db.categories || []).map((cat: any) => (
                          <div key={cat.id} className="py-2 flex items-center justify-between">
                            <div>
                              <span className="font-bold text-slate-900">{cat.name}</span>
                              <span className="text-slate-500 ml-2">
                                · {cat.nameBn} · {cat.nameAr}
                              </span>
                            </div>
                            <button
                              onClick={async () => {
                                const next = (db.categories || []).filter((c: any) => c.id !== cat.id);
                                await syncDB({ categories: next }, `Removed category ${cat.name}`, 'Inventory');
                              }}
                              className="text-rose-600 hover:underline text-[11px]"
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {invTab === 'transfer' && (
                  <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">
                      Inter-Branch Stock Transfer History (Mabellah · Seeb · Ruwi · Sohar)
                    </h3>
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                          <th className="py-2.5 px-3">Date</th>
                          <th className="py-2.5 px-3">Product</th>
                          <th className="py-2.5 px-3">From Branch</th>
                          <th className="py-2.5 px-3">To Branch</th>
                          <th className="py-2.5 px-3 text-right">Qty</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {(db.itemTransfers || []).map((tr: any) => (
                          <tr key={tr.id}>
                            <td className="py-2.5 px-3 font-mono">{tr.date}</td>
                            <td className="py-2.5 px-3 font-semibold">{tr.product}</td>
                            <td className="py-2.5 px-3">{tr.fromBranch}</td>
                            <td className="py-2.5 px-3">{tr.toBranch}</td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold">{tr.qty}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ==================== 4. OMAN TELECOM, MARGIN & LATENCY ==================== */}
            {activeModule === 'telecom' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      {t('telecom_oman', 'Oman Telecom Operations, Margin Analysis & Network Latency')}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Omantel, Ooredoo, Vodafone, FRiENDi, Renna & Awasr Fiber · Editable Dealer Profit Margins
                    </p>
                  </div>
                  <button
                    onClick={runOmanNetworkLatencyProbe}
                    disabled={latencySimulating}
                    className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <Activity className="h-4 w-4 text-emerald-400" />
                    <span>{latencySimulating ? 'Probing Oman Switches...' : 'Run Live Latency Probe'}</span>
                  </button>
                </div>

                {/* Operator Cards with Editable Margin & Pool Top-up */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(db.telecomOperators || []).map((op: any) => (
                    <div
                      key={op.id}
                      className="rounded-xl border border-slate-200 bg-white p-5 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className="px-2.5 py-1 rounded text-xs font-bold text-white"
                            style={{ backgroundColor: op.color }}
                          >
                            {op.code}
                          </span>
                          <h3 className="text-sm font-bold text-slate-900">{op.name}</h3>
                        </div>
                        <span className="text-xs font-mono font-semibold text-emerald-700">
                          {op.latencyMs}ms · {op.reliability}%
                        </span>
                      </div>

                      <div className="rounded-lg bg-slate-50 p-3 border border-slate-100 flex items-center justify-between">
                        <div>
                          <div className="text-[11px] text-slate-500">Dealer Pool Balance</div>
                          <div className="text-lg font-bold font-mono text-slate-950 tabular-nums">
                            {fmt(op.balance)} {config.currency}
                          </div>
                        </div>
                        <button
                          onClick={async () => {
                            const updated = (db.telecomOperators || []).map((x: any) =>
                              x.id === op.id ? { ...x, balance: Number(x.balance) + 50 } : x
                            );
                            await syncDB(
                              { telecomOperators: updated },
                              `Added +50.000 OMR dealer balance to ${op.name}`,
                              'Telecom'
                            );
                            SoundEngine.success();
                            showToast(`Added +50.000 OMR to ${op.name} pool`, 'success');
                          }}
                          className="rounded-lg border border-emerald-600 px-2.5 py-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-50"
                        >
                          +50 OMR Pool
                        </button>
                      </div>

                      {/* Editable Profit Margin */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-1">Margin Value</label>
                          <input
                            type="number"
                            step="0.005"
                            value={op.commissionValue}
                            onChange={async (e) => {
                              const val = parseFloat(e.target.value) || 0;
                              const updated = (db.telecomOperators || []).map((x: any) =>
                                x.id === op.id ? { ...x, commissionValue: val } : x
                              );
                              await syncDB({ telecomOperators: updated });
                            }}
                            className="w-full rounded border border-slate-300 px-2.5 py-1 text-xs font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-1">Margin Type</label>
                          <select
                            value={op.commissionType}
                            onChange={async (e) => {
                              const updated = (db.telecomOperators || []).map((x: any) =>
                                x.id === op.id ? { ...x, commissionType: e.target.value } : x
                              );
                              await syncDB({ telecomOperators: updated });
                            }}
                            className="w-full rounded border border-slate-300 px-2 py-1 text-xs"
                          >
                            <option value="percent">% Percentage</option>
                            <option value="fixed">Fixed OMR</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Dealer Recharge Execution Terminal */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const op = (db.telecomOperators || []).find(
                        (o: any) => o.id === Number(selectedTelecomOpId)
                      );
                      const amt = parseFloat(telecomAmount);
                      if (!op || isNaN(amt) || amt <= 0) return;
                      if (op.balance < amt) {
                        showToast(`Insufficient pool balance for ${op.name}`, 'error');
                        return;
                      }
                      const profit =
                        op.commissionType === 'fixed'
                          ? Number(op.commissionValue)
                          : (amt * Number(op.commissionValue)) / 100;

                      const tx = {
                        id: Date.now(),
                        txNo: `TEL-${Math.floor(1000 + Math.random() * 9000)}`,
                        operatorId: op.id,
                        operatorName: op.name,
                        phone: telecomPhone,
                        amount: amt,
                        profit,
                        previousBalance: op.balance,
                        newBalance: op.balance - amt,
                        date: new Date().toISOString(),
                        dealer: currentUser?.username || 'dealer1',
                        branch: currentUser?.branch || 'Mabellah Main Branch',
                      };
                      const updatedOps = (db.telecomOperators || []).map((o: any) =>
                        o.id === op.id ? { ...o, balance: o.balance - amt } : o
                      );
                      await syncDB(
                        {
                          telecomOperators: updatedOps,
                          telecomTransactions: [tx, ...(db.telecomTransactions || [])],
                        },
                        `Telecom Top-up ${tx.txNo}: ${op.name} (${fmt(amt)} OMR, Profit: ${fmt(profit)} OMR)`,
                        'Telecom'
                      );
                      SoundEngine.success();
                      showToast(
                        `Top-up ${tx.txNo} complete! Dealer Profit: +${fmt(profit)} ${config.currency}`,
                        'success'
                      );
                    }}
                    className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-4"
                  >
                    <h3 className="text-sm font-bold text-slate-900">
                      Execute Dealer Top-Up / Bill Settlement
                    </h3>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Operator
                      </label>
                      <select
                        value={selectedTelecomOpId}
                        onChange={(e) => setSelectedTelecomOpId(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
                      >
                        {(db.telecomOperators || []).map((o: any) => (
                          <option key={o.id} value={o.id}>
                            {o.name} (Pool: {fmt(o.balance)} OMR)
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Subscriber Phone / Fiber Account No
                      </label>
                      <input
                        type="text"
                        value={telecomPhone}
                        onChange={(e) => setTelecomPhone(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Top-Up Amount ({config.currency})
                      </label>
                      <input
                        type="number"
                        step="0.001"
                        value={telecomAmount}
                        onChange={(e) => setTelecomAmount(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full rounded-lg bg-emerald-600 py-2.5 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      Execute Top-Up & Log Commission Profit
                    </button>
                  </form>

                  <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                    <h3 className="text-sm font-bold text-slate-900">
                      Telecom Profit Margin Ledger & Recent Transactions
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                            <th className="py-2 px-3">Tx ID</th>
                            <th className="py-2 px-3">Operator</th>
                            <th className="py-2 px-3">Subscriber</th>
                            <th className="py-2 px-3 text-right">Amount</th>
                            <th className="py-2 px-3 text-right">Margin Profit</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(db.telecomTransactions || []).map((tx: any) => (
                            <tr key={tx.id}>
                              <td className="py-2 px-3 font-mono font-semibold">{tx.txNo}</td>
                              <td className="py-2 px-3">{tx.operatorName}</td>
                              <td className="py-2 px-3 font-mono">{tx.phone}</td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums">
                                {fmt(tx.amount)}
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                                +{fmt(tx.profit)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 5. OFFERS & PLAN COMPARISON ENGINE ==================== */}
            {activeModule === 'offers' && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-xl font-bold text-slate-950">
                    {t('offers_engine', 'Offers Card & Subscription Plan Comparison Engine')}
                  </h1>
                  <p className="text-xs text-slate-500">
                    Rapid deal evaluation across Oman 5G mobile & home fiber subscription plans with dealer commission breakdown.
                  </p>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-5 overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                        <th className="py-3 px-4">Operator & Plan</th>
                        <th className="py-3 px-4 text-right">Monthly Fee</th>
                        <th className="py-3 px-4 text-right">Data Quota</th>
                        <th className="py-3 px-4 text-right">Voice (Local/Intl)</th>
                        <th className="py-3 px-4 text-right">Dealer Margin %</th>
                        <th className="py-3 px-4 text-right">Net Dealer Profit / Sale</th>
                        <th className="py-3 px-4">Evaluation Tag</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(db.subscriptionPlans || []).map((plan: any) => {
                        const netDealerOmr = (plan.priceOmr * plan.dealerMarginPct) / 100;
                        return (
                          <tr key={plan.id} className="hover:bg-slate-50">
                            <td className="py-3 px-4 font-bold text-slate-900">
                              {plan.operator} — {plan.planName}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                              {fmt(plan.priceOmr)} {config.currency}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums">
                              {plan.dataGb >= 9000 ? 'Unlimited' : `${plan.dataGb} GB`}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums">
                              {plan.localMinutes}m / {plan.intlMinutes}m
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-emerald-700 font-semibold tabular-nums">
                              {plan.dealerMarginPct}%
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                              +{fmt(netDealerOmr)} {config.currency}
                            </td>
                            <td className="py-3 px-4 text-slate-600">{plan.badge}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ==================== 6. VIP CUSTOMERS & BRANCH SEGMENTS ==================== */}
            {activeModule === 'vip' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      {t('vip_crm', 'VIP Customers, Regional Branches & Targeted Loyalty Campaigns')}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Segment customers across Mabellah, Seeb, Ruwi & Sohar branches by historical spend and dispatch personalized Gmail offers.
                    </p>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-5 overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                        <th className="py-2.5 px-3">Customer Name</th>
                        <th className="py-2.5 px-3">Branch Segment</th>
                        <th className="py-2.5 px-3">VIP Tier</th>
                        <th className="py-2.5 px-3 text-right">Historical Purchases</th>
                        <th className="py-2.5 px-3 text-right">Loyalty Points</th>
                        <th className="py-2.5 px-3 text-right">Targeted Campaign</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(db.customers || []).map((c: any) => (
                        <tr key={c.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-slate-900">{c.name}</div>
                            <div className="text-[11px] font-mono text-slate-500">
                              {c.phone} · {c.email}
                            </div>
                          </td>
                          <td className="py-2.5 px-3">{c.branch}</td>
                          <td className="py-2.5 px-3 font-semibold text-emerald-700">{c.segment}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                            {fmt(c.totalPurchases)} {config.currency}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                            {c.loyaltyPoints} pts
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={() =>
                                requestGmailSend(
                                  c.email,
                                  `Exclusive ${c.segment} Offer from ${config.businessName}`,
                                  `<p>Dear <strong>${c.name}</strong>,</p>
                                  <p>Thank you for being a valued <strong>${c.segment}</strong> member at our <strong>${c.branch}</strong> with ${c.loyaltyPoints} loyalty points.</p>
                                  <p>Present this email at our showroom for 15% VIP discount on flagship 5G devices and complimentary screen protection!</p>`
                                )
                              }
                              className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-600"
                            >
                              <Mail className="h-3 w-3" /> Send VIP Offer
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ==================== 7. EMPLOYEES & PAYROLL ==================== */}
            {activeModule === 'employees' && (
              <div className="space-y-6">
                <h1 className="text-xl font-bold text-slate-950">
                  {t('employees_hr', 'Employee Directory, Attendance & Oman Payroll')}
                </h1>
                <div className="rounded-xl border border-slate-200 bg-white p-5 overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                        <th className="py-2.5 px-3">Employee Name</th>
                        <th className="py-2.5 px-3">Designation</th>
                        <th className="py-2.5 px-3">Branch</th>
                        <th className="py-2.5 px-3">Phone</th>
                        <th className="py-2.5 px-3 text-right">Monthly Salary</th>
                        <th className="py-2.5 px-3 text-right">Sales Commission</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(db.employees || []).map((emp: any) => (
                        <tr key={emp.id}>
                          <td className="py-2.5 px-3 font-bold text-slate-900">{emp.name}</td>
                          <td className="py-2.5 px-3">{emp.position}</td>
                          <td className="py-2.5 px-3">{emp.branch}</td>
                          <td className="py-2.5 px-3 font-mono">{emp.phone}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                            {fmt(emp.salary)} {config.currency}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                            {emp.commissionPct}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ==================== 8. REPORTS, DATE FILTER, PDF & EXCEL EXPORT ==================== */}
            {activeModule === 'reports' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      {t('reports_analytics', 'Date-Range Financial Reports, A4 PDF Invoices & Excel Export')}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Filter sales, purchases, and telecom margins from-to any date and export directly to Excel CSV or print A4 PDF.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="date"
                      value={reportFromDate}
                      onChange={(e) => setReportFromDate(e.target.value)}
                      className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono bg-white"
                    />
                    <span className="text-xs text-slate-500">to</span>
                    <input
                      type="date"
                      value={reportToDate}
                      onChange={(e) => setReportToDate(e.target.value)}
                      className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono bg-white"
                    />
                    <button
                      onClick={() =>
                        exportToExcelCSV(
                          `RST_Sales_Report_${reportFromDate}_to_${reportToDate}`,
                          ['Invoice No', 'Date', 'Customer', 'Branch', 'Subtotal OMR', 'VAT OMR', 'Grand Total OMR', 'Profit OMR', 'Payment'],
                          (db.invoices || []).map((i: any) => [
                            i.invoice_no,
                            new Date(i.date).toLocaleDateString(),
                            i.customer,
                            i.branch,
                            fmt(i.subtotal),
                            fmt(i.vat),
                            fmt(i.grand_total),
                            fmt(i.profit),
                            i.payment,
                          ])
                        )
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      <Download className="h-3.5 w-3.5" /> Export Sales Excel (CSV)
                    </button>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-5 overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                        <th className="py-2.5 px-3">Invoice No</th>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Customer</th>
                        <th className="py-2.5 px-3">Branch</th>
                        <th className="py-2.5 px-3 text-right">Subtotal</th>
                        <th className="py-2.5 px-3 text-right">VAT</th>
                        <th className="py-2.5 px-3 text-right">Net Total</th>
                        <th className="py-2.5 px-3 text-right">Profit</th>
                        <th className="py-2.5 px-3 text-right">Print PDF</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(db.invoices || [])
                        .filter((inv: any) => {
                          const d = (inv.date || '').slice(0, 10);
                          return d >= reportFromDate && d <= reportToDate;
                        })
                        .map((inv: any) => (
                          <tr key={inv.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-mono font-bold">{inv.invoice_no}</td>
                            <td className="py-2.5 px-3 font-mono">
                              {new Date(inv.date).toLocaleDateString()}
                            </td>
                            <td className="py-2.5 px-3">{inv.customer}</td>
                            <td className="py-2.5 px-3">{inv.branch}</td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                              {fmt(inv.subtotal)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                              {fmt(inv.vat)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-950 tabular-nums">
                              {fmt(inv.grand_total)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-semibold text-emerald-700 tabular-nums">
                              +{fmt(inv.profit)}
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              <button
                                onClick={() => printTaxInvoice(inv, config, 'a4')}
                                className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-[11px] font-semibold hover:bg-slate-100"
                              >
                                <Printer className="h-3 w-3" /> A4 Invoice
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ==================== 9. ROLES, PERMISSIONS, LOGS & GMAIL ALERTS ==================== */}
            {activeModule === 'security' && (
              <div className="space-y-6">
                <h1 className="text-xl font-bold text-slate-950">
                  {t('security_rbac', 'Role-Based Access Control (RBAC), Activity Logs & Gmail Alerts')}
                </h1>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Staff Permissions Matrix */}
                  <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">
                      User Roles, PIN & Custom Permission Settings
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                            <th className="py-2 px-3">User / Role</th>
                            <th className="py-2 px-3">Branch</th>
                            <th className="py-2 px-3">PIN</th>
                            <th className="py-2 px-3">Allowed Modules</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(db.users || []).map((u: any) => (
                            <tr key={u.id}>
                              <td className="py-2.5 px-3">
                                <div className="font-bold text-slate-900">{u.fullname}</div>
                                <div className="text-[11px] text-slate-500">
                                  @{u.username} · {u.role.toUpperCase()}
                                </div>
                              </td>
                              <td className="py-2.5 px-3">{u.branch}</td>
                              <td className="py-2.5 px-3 font-mono">{u.pin}</td>
                              <td className="py-2.5 px-3">
                                <div className="flex flex-wrap gap-1">
                                  {['pos', 'inventory', 'telecom', 'reports', 'vip'].map((perm) => {
                                    const hasPerm =
                                      u.role === 'admin' ||
                                      (u.permissions || []).includes('all') ||
                                      (u.permissions || []).includes(perm);
                                    return (
                                      <button
                                        key={perm}
                                        disabled={u.role === 'admin'}
                                        onClick={async () => {
                                          const curPerms: string[] = u.permissions || [];
                                          const nextPerms = curPerms.includes(perm)
                                            ? curPerms.filter((p) => p !== perm)
                                            : [...curPerms, perm];
                                          const updatedUsers = (db.users || []).map((usr: any) =>
                                            usr.id === u.id ? { ...usr, permissions: nextPerms } : usr
                                          );
                                          await syncDB(
                                            { users: updatedUsers },
                                            `Updated permissions for ${u.username}`,
                                            'Security'
                                          );
                                        }}
                                        className={`px-2 py-0.5 rounded text-[11px] font-medium border ${
                                          hasPerm
                                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                                            : 'bg-slate-50 border-slate-200 text-slate-400'
                                        }`}
                                      >
                                        {perm}
                                      </button>
                                    );
                                  })}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Real-Time Audit Logs */}
                  <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                    <h3 className="text-sm font-bold text-slate-900">
                      Real-Time System Audit & Activity Logs
                    </h3>
                    <div className="space-y-2 max-h-80 overflow-y-auto text-xs">
                      {(db.auditLogs || []).slice(0, 20).map((log: any) => (
                        <div
                          key={log.id}
                          className="rounded-lg border border-slate-100 bg-slate-50 p-2.5 space-y-0.5"
                        >
                          <div className="flex justify-between text-[11px] text-slate-500">
                            <span className="font-semibold text-slate-800">
                              @{log.user} · {log.module}
                            </span>
                            <span className="font-mono">
                              {new Date(log.time).toLocaleTimeString()}
                            </span>
                          </div>
                          <div className="text-slate-700">{log.action}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 10. THEME, SOUND & MULTI-LANGUAGE EDITOR ==================== */}
            {activeModule === 'theme' && (
              <div className="space-y-6">
                <h1 className="text-xl font-bold text-slate-950">
                  {t('theme_lang', 'Admin Theme Customizer, Business Info & EN / BN / AR Dictionary Editor')}
                </h1>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Business Info & Theme Settings */}
                  <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">
                      Business Identity & Theme Control
                    </h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Business Brand Name
                        </label>
                        <input
                          type="text"
                          value={config.businessName || ''}
                          onChange={(e) =>
                            syncDB({ themeConfig: { ...config, businessName: e.target.value } })
                          }
                          className="w-full rounded-lg border border-slate-300 px-3 py-2"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Oman Legal Entity Name
                        </label>
                        <input
                          type="text"
                          value={config.legalName || ''}
                          onChange={(e) =>
                            syncDB({ themeConfig: { ...config, legalName: e.target.value } })
                          }
                          className="w-full rounded-lg border border-slate-300 px-3 py-2"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">CR Number</label>
                          <input
                            type="text"
                            value={config.crNo || ''}
                            onChange={(e) =>
                              syncDB({ themeConfig: { ...config, crNo: e.target.value } })
                            }
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">VAT Rate (%)</label>
                          <input
                            type="number"
                            value={config.vatRate ?? 5}
                            onChange={(e) =>
                              syncDB({
                                themeConfig: { ...config, vatRate: parseFloat(e.target.value) || 0 },
                              })
                            }
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Currency Code</label>
                          <input
                            type="text"
                            value={config.currency || 'OMR'}
                            onChange={(e) =>
                              syncDB({ themeConfig: { ...config, currency: e.target.value } })
                            }
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Decimal Places</label>
                          <input
                            type="number"
                            min={0}
                            max={4}
                            value={config.decimalPlaces ?? 3}
                            onChange={(e) =>
                              syncDB({
                                themeConfig: {
                                  ...config,
                                  decimalPlaces: parseInt(e.target.value, 10) || 2,
                                },
                              })
                            }
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Primary Theme Color</label>
                          <div className="flex items-center gap-2">
                            <input
                              type="color"
                              value={config.primaryColor || '#059669'}
                              onChange={(e) =>
                                syncDB({ themeConfig: { ...config, primaryColor: e.target.value } })
                              }
                              className="h-8 w-10 rounded border border-slate-300 cursor-pointer"
                            />
                            <input
                              type="text"
                              value={config.primaryColor || '#059669'}
                              onChange={(e) =>
                                syncDB({ themeConfig: { ...config, primaryColor: e.target.value } })
                              }
                              className="flex-1 rounded-lg border border-slate-300 px-2 py-1.5 font-mono text-xs"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Showroom Phone</label>
                          <input
                            type="text"
                            value={config.phone || ''}
                            onChange={(e) =>
                              syncDB({ themeConfig: { ...config, phone: e.target.value } })
                            }
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Showroom Address</label>
                        <input
                          type="text"
                          value={config.address || ''}
                          onChange={(e) =>
                            syncDB({ themeConfig: { ...config, address: e.target.value } })
                          }
                          className="w-full rounded-lg border border-slate-300 px-3 py-2"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Admin Notification Email
                        </label>
                        <input
                          type="email"
                          value={config.email || ''}
                          onChange={(e) =>
                            syncDB({ themeConfig: { ...config, email: e.target.value } })
                          }
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Live Tri-Language Dictionary Editor */}
                  <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900">
                        Live Multi-Language String Editor (English · বাংলা · العربية)
                      </h3>
                      <button
                        onClick={() => {
                          const newKey = `custom_label_${Object.keys(db.translations?.en || {}).length + 1}`;
                          const nextTrans = {
                            en: { ...(db.translations?.en || {}), [newKey]: 'Custom Label' },
                            bn: { ...(db.translations?.bn || {}), [newKey]: 'কাস্টম লেবেল' },
                            ar: { ...(db.translations?.ar || {}), [newKey]: 'تسمية مخصصة' },
                          };
                          syncDB({ translations: nextTrans }, `Added translation key ${newKey}`, 'Theme');
                        }}
                        className="rounded-lg bg-emerald-600 px-3 py-1 text-xs font-semibold text-white hover:bg-emerald-700"
                      >
                        + Add Translation Key
                      </button>
                    </div>
                    <div className="overflow-x-auto max-h-96">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                            <th className="py-2 px-2">Key</th>
                            <th className="py-2 px-2">English (EN)</th>
                            <th className="py-2 px-2">বাংলা (BN)</th>
                            <th className="py-2 px-2">العربية (AR)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {Object.keys(db.translations?.en || {}).map((key) => (
                            <tr key={key}>
                              <td className="py-2 px-2 font-mono text-[11px] text-slate-500">
                                {key}
                              </td>
                              {(['en', 'bn', 'ar'] as const).map((lCode) => (
                                <td key={lCode} className="py-2 px-2">
                                  <input
                                    type="text"
                                    value={db.translations?.[lCode]?.[key] || ''}
                                    onChange={(e) => {
                                      const nextTrans = {
                                        ...db.translations,
                                        [lCode]: {
                                          ...(db.translations?.[lCode] || {}),
                                          [key]: e.target.value,
                                        },
                                      };
                                      syncDB({ translations: nextTrans });
                                    }}
                                    className="w-full rounded border border-slate-200 px-2 py-1 text-xs"
                                  />
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 11. REPAIRS, CCTV & EXPENSES HUB ==================== */}
            {activeModule === 'repairs' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h1 className="text-xl font-bold text-slate-950">
                      Mobile Repair Job Cards, Showroom CCTV Feeds & Petty Cash Expenses
                    </h1>
                    <p className="text-xs text-slate-500">
                      Every repair status, estimated cost, CCTV NVR stream config, and showroom expense is editable inline.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveModule('master_editor')}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <Sliders className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Open Full Spreadsheet Editor</span>
                  </button>
                </div>

                {/* Mobile & Device Repair Tickets */}
                <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900">
                      Active Mobile & Laptop Repair Job Cards (Inline Editable)
                    </h3>
                    <button
                      onClick={async () => {
                        const newTicket = {
                          id: Date.now(),
                          ticketNumber: `JOB-${Math.floor(1000 + Math.random() * 9000)}`,
                          customerName: 'New Repair Customer',
                          customerPhone: '+968 9000 0000',
                          deviceModel: 'iPhone 15 Pro',
                          imei: generateIMEI(),
                          issueDescription: 'Display / Battery Diagnostic',
                          status: 'received',
                          estimatedCost: 40.0,
                          advancePaid: 10.0,
                          technician: 'Kamrul Hasan',
                          branch: currentUser?.branch || 'Mabellah Main Branch',
                        };
                        await syncDB(
                          { repairTickets: [newTicket, ...(db.repairTickets || [])] },
                          `Created Repair Job Card ${newTicket.ticketNumber}`,
                          'Repairs'
                        );
                        SoundEngine.success();
                      }}
                      className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                    >
                      + New Job Card
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                          <th className="py-2 px-2.5">Ticket #</th>
                          <th className="py-2 px-2.5">Customer & Phone</th>
                          <th className="py-2 px-2.5">Device & IMEI</th>
                          <th className="py-2 px-2.5">Fault / Issue</th>
                          <th className="py-2 px-2.5">Status</th>
                          <th className="py-2 px-2.5 text-right">Est. Cost ({config.currency})</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {(db.repairTickets || []).map((tkt: any) => (
                          <tr key={tkt.id}>
                            <td className="py-2 px-2.5 font-mono font-bold">{tkt.ticketNumber}</td>
                            <td className="py-2 px-2.5">
                              <input
                                type="text"
                                value={tkt.customerName}
                                onChange={(e) => {
                                  const next = (db.repairTickets || []).map((x: any) =>
                                    x.id === tkt.id ? { ...x, customerName: e.target.value } : x
                                  );
                                  syncDB({ repairTickets: next });
                                }}
                                className="w-full rounded border border-slate-200 px-2 py-1 text-xs font-semibold"
                              />
                            </td>
                            <td className="py-2 px-2.5">
                              <input
                                type="text"
                                value={tkt.deviceModel}
                                onChange={(e) => {
                                  const next = (db.repairTickets || []).map((x: any) =>
                                    x.id === tkt.id ? { ...x, deviceModel: e.target.value } : x
                                  );
                                  syncDB({ repairTickets: next });
                                }}
                                className="w-full rounded border border-slate-200 px-2 py-1 text-xs"
                              />
                            </td>
                            <td className="py-2 px-2.5">
                              <input
                                type="text"
                                value={tkt.issueDescription}
                                onChange={(e) => {
                                  const next = (db.repairTickets || []).map((x: any) =>
                                    x.id === tkt.id ? { ...x, issueDescription: e.target.value } : x
                                  );
                                  syncDB({ repairTickets: next });
                                }}
                                className="w-full rounded border border-slate-200 px-2 py-1 text-xs"
                              />
                            </td>
                            <td className="py-2 px-2.5">
                              <select
                                value={tkt.status}
                                onChange={(e) => {
                                  const next = (db.repairTickets || []).map((x: any) =>
                                    x.id === tkt.id ? { ...x, status: e.target.value } : x
                                  );
                                  syncDB({ repairTickets: next });
                                }}
                                className="rounded border border-slate-300 px-2 py-1 text-xs font-semibold"
                              >
                                <option value="received">Received</option>
                                <option value="diagnosing">Diagnosing</option>
                                <option value="in_progress">In Progress</option>
                                <option value="waiting_parts">Waiting Parts</option>
                                <option value="completed">Completed</option>
                                <option value="delivered">Delivered</option>
                              </select>
                            </td>
                            <td className="py-2 px-2.5 text-right">
                              <input
                                type="number"
                                step="0.001"
                                value={tkt.estimatedCost}
                                onChange={(e) => {
                                  const next = (db.repairTickets || []).map((x: any) =>
                                    x.id === tkt.id
                                      ? { ...x, estimatedCost: parseFloat(e.target.value) || 0 }
                                      : x
                                  );
                                  syncDB({ repairTickets: next });
                                }}
                                className="w-24 rounded border border-slate-200 px-2 py-1 text-right font-mono text-xs font-bold"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* CCTV NVR Camera Channels & Showroom Expenses */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                    <h3 className="text-sm font-bold text-slate-900">
                      Oman Showroom & Warehouse CCTV NVR Channels
                    </h3>
                    <div className="space-y-2.5">
                      {(db.cctvMonitors || []).map((cam: any) => (
                        <div
                          key={cam.id}
                          className="rounded-lg border border-slate-200 p-3 flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex-1 space-y-1">
                            <input
                              type="text"
                              value={cam.cameraName}
                              onChange={(e) => {
                                const next = (db.cctvMonitors || []).map((c: any) =>
                                  c.id === cam.id ? { ...c, cameraName: e.target.value } : c
                                );
                                syncDB({ cctvMonitors: next });
                              }}
                              className="w-full rounded border border-slate-200 px-2 py-1 font-bold text-slate-900"
                            />
                            <div className="text-[11px] text-slate-500 font-mono">
                              IP: {cam.ipAddress} · {cam.resolution} · {cam.recordingMode}
                            </div>
                          </div>
                          <span className="font-mono text-xs font-bold text-emerald-700">
                            {cam.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900">
                        Showroom Operational Expenses & Petty Cash
                      </h3>
                      <button
                        onClick={async () => {
                          const exp = {
                            id: Date.now(),
                            date: new Date().toISOString().slice(0, 10),
                            category: 'Showroom Expense',
                            description: 'New petty cash voucher',
                            amount: 10.0,
                            paymentMethod: 'Cash',
                            branch: currentUser?.branch || 'Mabellah Main Branch',
                          };
                          await syncDB({ expenses: [exp, ...(db.expenses || [])] });
                        }}
                        className="rounded bg-slate-900 px-2.5 py-1 text-xs font-semibold text-white"
                      >
                        + Log Expense
                      </button>
                    </div>
                    <div className="space-y-2">
                      {(db.expenses || []).map((ex: any) => (
                        <div
                          key={ex.id}
                          className="rounded-lg border border-slate-200 p-2.5 flex items-center justify-between gap-2 text-xs"
                        >
                          <input
                            type="text"
                            value={ex.description}
                            onChange={(e) => {
                              const next = (db.expenses || []).map((x: any) =>
                                x.id === ex.id ? { ...x, description: e.target.value } : x
                              );
                              syncDB({ expenses: next });
                            }}
                            className="flex-1 rounded border border-slate-200 px-2 py-1"
                          />
                          <input
                            type="number"
                            step="0.001"
                            value={ex.amount}
                            onChange={(e) => {
                              const next = (db.expenses || []).map((x: any) =>
                                x.id === ex.id
                                  ? { ...x, amount: parseFloat(e.target.value) || 0 }
                                  : x
                              );
                              syncDB({ expenses: next });
                            }}
                            className="w-24 rounded border border-slate-200 px-2 py-1 text-right font-mono font-bold text-rose-700"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==================== 12. UNIVERSAL ADMIN MASTER EDITOR ==================== */}
            {activeModule === 'master_editor' && (
              <AdminMasterEditor
                db={db}
                onSyncDB={syncDB}
                onResetDefaultDB={async () => {
                  const res = await fetch('/api/state/reset', { method: 'POST' });
                  const fresh = await res.json();
                  setDb(fresh);
                  SoundEngine.success();
                  showToast('Reset cloud database to factory defaults', 'info');
                }}
                showToast={showToast}
              />
            )}
          </main>
        </div>
      )}

      {/* User Confirmation Modal for Gmail Send (Workspace Integration Mandatory Guard) */}
      {emailConfirmModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-2.5 text-slate-900">
              <Mail className="h-5 w-5 text-emerald-600" />
              <h3 className="text-base font-bold">Confirm Gmail Notification Send</h3>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to send this email via your connected Google Workspace Gmail account?
            </p>
            <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 text-xs space-y-1">
              <div>
                <strong>Recipient:</strong> <span className="font-mono">{emailConfirmModal.to}</span>
              </div>
              <div>
                <strong>Subject:</strong> {emailConfirmModal.subject}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() =>
                  setEmailConfirmModal({ isOpen: false, to: '', subject: '', htmlBody: '' })
                }
                className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={sendingEmail}
                onClick={confirmAndSendGmail}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                <Send className="h-3.5 w-3.5" />
                <span>{sendingEmail ? 'Sending...' : 'Confirm & Send Email'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Camera Barcode / IMEI Scanner Modal */}
      <BarcodeScannerModal
        isOpen={scannerModal.isOpen}
        onClose={() => setScannerModal({ ...scannerModal, isOpen: false })}
        onScanSuccess={handleBarcodeScanned}
      />

      {/* Floating Gemini AI Copilot */}
      <GeminiCopilot lang={lang} businessName={config.businessName || 'RST ELECTRONICS'} />
    </div>
  );
}
