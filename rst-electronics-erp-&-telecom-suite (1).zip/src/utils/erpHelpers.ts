// Synthesized Web Audio API Sound Engine for POS & ERP Actions
class SoundEngineManager {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  public play(freq: number, duration: number, type: OscillatorType = 'sine', volume = 0.08) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch {
      // Ignore audio unlock errors
    }
  }

  public beep() {
    this.play(1040, 0.09, 'sine', 0.1);
  }

  public click() {
    this.play(620, 0.04, 'sine', 0.04);
  }

  public success() {
    this.play(880, 0.12, 'sine', 0.08);
    setTimeout(() => this.play(1320, 0.18, 'sine', 0.09), 90);
  }

  public error() {
    this.play(220, 0.28, 'sawtooth', 0.12);
  }

  public notify() {
    this.play(660, 0.12, 'triangle', 0.08);
    setTimeout(() => this.play(990, 0.16, 'triangle', 0.08), 110);
  }
}

export const SoundEngine = new SoundEngineManager();

// Luhn-validated EAN-13 Barcode Generator
export function generateEAN13(): string {
  const base = '890' + String(Date.now()).slice(-9);
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    sum += parseInt(base[i], 10) * (i % 2 === 0 ? 1 : 3);
  }
  const check = (10 - (sum % 10)) % 10;
  return base + check;
}

// Luhn-validated 15-Digit TAC IMEI Generator
export function generateIMEI(): string {
  const imei = '35' + String(Date.now()).slice(-12);
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    let d = parseInt(imei[i], 10);
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  const check = (10 - (sum % 10)) % 10;
  return imei + check;
}

// Serial Number Generator
export function generateSerialNo(prefix = 'RST'): string {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
}

// Print A4 / Thermal Tax Invoice with Barcode & Oman CR Details
export function printTaxInvoice(invoice: any, config: any, format: 'a4' | 'thermal' = 'a4') {
  const decimals = config?.decimalPlaces ?? 3;
  const currency = config?.currency || 'OMR';
  const fmt = (n: any) => Number(n || 0).toFixed(decimals);

  const itemsRows = (invoice.items || [])
    .map(
      (item: any, idx: number) => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${idx + 1}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">
          <strong>${item.name}</strong>
          ${item.imei ? `<br/><span style="font-size:11px;color:#475569;">IMEI: ${item.imei}</span>` : ''}
          ${item.barcode ? `<br/><span style="font-size:10px;color:#64748b;">Code: ${item.barcode}</span>` : ''}
        </td>
        <td style="padding: 8px; text-align: right; border-bottom: 1px solid #e2e8f0; font-family: monospace;">${fmt(item.price)}</td>
        <td style="padding: 8px; text-align: center; border-bottom: 1px solid #e2e8f0; font-family: monospace;">${item.qty}</td>
        <td style="padding: 8px; text-align: right; border-bottom: 1px solid #e2e8f0; font-family: monospace; font-weight: bold;">${fmt(item.price * item.qty)}</td>
      </tr>`
    )
    .join('');

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Tax Invoice ${invoice.invoice_no}</title>
  <style>
    @page { size: ${format === 'a4' ? 'A4' : '80mm auto'}; margin: ${format === 'a4' ? '14mm' : '4mm'}; }
    body {
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      color: #0f172a;
      max-width: ${format === 'a4' ? '780px' : '300px'};
      margin: 0 auto;
      padding: ${format === 'a4' ? '20px' : '8px'};
      font-size: ${format === 'a4' ? '13px' : '11px'};
    }
    .header {
      text-align: center;
      border-bottom: 2px solid #059669;
      padding-bottom: 14px;
      margin-bottom: 16px;
    }
    .header h1 { margin: 0; color: #059669; font-size: ${format === 'a4' ? '26px' : '18px'}; letter-spacing: 1px; }
    .header p { margin: 3px 0; color: #475569; font-size: 12px; }
    .badge-title {
      background: #0f172a;
      color: #fff;
      text-align: center;
      padding: 7px;
      font-weight: 700;
      letter-spacing: 2px;
      margin: 14px 0;
      border-radius: 4px;
    }
    .meta-grid {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
      gap: 12px;
      flex-wrap: wrap;
    }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    thead { background: #f1f5f9; color: #0f172a; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1; }
    th { padding: 8px; text-align: left; font-size: 11px; text-transform: uppercase; }
    .totals { width: ${format === 'a4' ? '45%' : '100%'}; margin-left: auto; }
    .totals td { padding: 5px 0; }
    .totals .grand { font-size: 16px; font-weight: 700; color: #059669; border-top: 2px solid #0f172a; padding-top: 8px; }
    .footer { text-align: center; margin-top: 30px; padding-top: 12px; border-top: 1px dashed #cbd5e1; color: #64748b; font-size: 11px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>${config?.businessName || 'RST ELECTRONICS'}</h1>
    <p><strong>${config?.legalName || 'AL WAHA AL KHDRA AL MUTAKAMILAH TRADING'}</strong></p>
    <p>CR No: ${config?.crNo || '1374092'} · ${config?.address || 'Mabellah Sanaya, Road No 6, Sultanate of Oman'}</p>
    <p>Tel: ${config?.phone || '+968 9430 1393'} · Email: ${config?.email || 'assalatasom@gmail.com'}</p>
  </div>
  <div class="badge-title">TAX INVOICE / فاتورة ضريبية / কর চালান</div>
  <div class="meta-grid">
    <div>
      <div><strong>Invoice No:</strong> ${invoice.invoice_no}</div>
      <div><strong>Date:</strong> ${new Date(invoice.date).toLocaleString()}</div>
      <div><strong>Branch:</strong> ${invoice.branch || 'Mabellah Main Branch'}</div>
    </div>
    <div style="text-align: right;">
      <div><strong>Customer:</strong> ${invoice.customer || 'Walk-in Customer'}</div>
      <div><strong>Payment Mode:</strong> ${invoice.payment || 'Cash'}</div>
      <div><strong>Status:</strong> ${invoice.status || 'Paid'}</div>
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Description / IMEI</th>
        <th style="text-align:right">Unit (${currency})</th>
        <th style="text-align:center">Qty</th>
        <th style="text-align:right">Total (${currency})</th>
      </tr>
    </thead>
    <tbody>
      ${itemsRows}
    </tbody>
  </table>
  <table class="totals">
    <tr>
      <td>Subtotal:</td>
      <td style="text-align:right;font-family:monospace;">${fmt(invoice.subtotal)} ${currency}</td>
    </tr>
    <tr>
      <td>Discount:</td>
      <td style="text-align:right;font-family:monospace;">-${fmt(invoice.discount || 0)} ${currency}</td>
    </tr>
    <tr>
      <td>VAT (${config?.vatRate ?? 5}%):</td>
      <td style="text-align:right;font-family:monospace;">${fmt(invoice.vat)} ${currency}</td>
    </tr>
    <tr class="grand">
      <td>NET TOTAL:</td>
      <td style="text-align:right;font-family:monospace;">${fmt(invoice.grand_total)} ${currency}</td>
    </tr>
  </table>
  <div class="footer">
    <p><strong>Thank you for shopping with ${config?.businessName || 'RST ELECTRONICS'}!</strong></p>
    <p>Warranty claims require original Tax Invoice and matching IMEI/Serial box.</p>
  </div>
</body>
</html>`;

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(html);
    doc.close();
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => document.body.removeChild(iframe), 2000);
    }, 300);
  }
}

// Export any dataset to Excel-compatible UTF-8 BOM CSV
export function exportToExcelCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '').replace(/"/g, '""');
    return `"${str}"`;
  };
  const csvContent =
    '\uFEFF' +
    [headers.map(escapeCell).join(','), ...rows.map((r) => r.map(escapeCell).join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
